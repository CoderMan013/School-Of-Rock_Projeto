-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.21.0.7344
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para escolamusica
CREATE DATABASE IF NOT EXISTS `escolamusica` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
USE `escolamusica`;

-- Copiando estrutura para tabela escolamusica.cargo
CREATE TABLE IF NOT EXISTS `cargo` (
  `idCargo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomeCargo` varchar(64) NOT NULL,
  PRIMARY KEY (`idCargo`),
  UNIQUE KEY `idCargo_UNIQUE` (`idCargo`),
  UNIQUE KEY `nomeCargo_UNIQUE` (`nomeCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Copiando dados para a tabela escolamusica.cargo: ~5 rows (aproximadamente)
INSERT IGNORE INTO `cargo` (`idCargo`, `nomeCargo`) VALUES
	(1, 'Administrador'),
	(2, 'Recepcionista'),
	(3, 'Professor de Bateria'),
	(4, 'Professor de Guitarra'),
	(5, 'Professor de Canto');

-- Copiando estrutura para tabela escolamusica.funcionario
CREATE TABLE IF NOT EXISTS `funcionario` (
  `idFuncionario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomeFuncionario` varchar(128) DEFAULT NULL,
  `email` varchar(64) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `recebeValeTransporte` tinyint(1) DEFAULT NULL,
  `Cargo_idCargo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idFuncionario`),
  UNIQUE KEY `idFuncionario_UNIQUE` (`idFuncionario`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `fk_Funcionario_Cargo_idx` (`Cargo_idCargo`),
  CONSTRAINT `fk_Funcionario_Cargo` FOREIGN KEY (`Cargo_idCargo`) REFERENCES `cargo` (`idCargo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Copiando dados para a tabela escolamusica.funcionario: ~5 rows (aproximadamente)
-- A senha de todos os registros abaixo é "123456", armazenada como hash bcrypt
-- gerado com password_hash() do PHP (o arquivo original trazia a senha em
-- texto puro, o que a API não aceita: o login usa password_verify()).
INSERT IGNORE INTO `funcionario` (`idFuncionario`, `nomeFuncionario`, `email`, `senha`, `recebeValeTransporte`, `Cargo_idCargo`) VALUES
	(1, 'Marcos Silva', 'marcos@escolamusica.com', '$2y$10$4131/n9OQQupat8XyQ/R7edZIx/MF94UQ3dWYXFOzUz9DzYKe8wp.', 1, 1),
	(2, 'Juliana Rocha', 'juliana@escolamusica.com', '$2y$10$4131/n9OQQupat8XyQ/R7edZIx/MF94UQ3dWYXFOzUz9DzYKe8wp.', 1, 2),
	(3, 'Ricardo Alves', 'ricardo@escolamusica.com', '$2y$10$4131/n9OQQupat8XyQ/R7edZIx/MF94UQ3dWYXFOzUz9DzYKe8wp.', 0, 3),
	(4, 'Fernando Lima', 'fernando@escolamusica.com', '$2y$10$4131/n9OQQupat8XyQ/R7edZIx/MF94UQ3dWYXFOzUz9DzYKe8wp.', 1, 4),
	(5, 'Camila Souza', 'camila@escolamusica.com', '$2y$10$4131/n9OQQupat8XyQ/R7edZIx/MF94UQ3dWYXFOzUz9DzYKe8wp.', 0, 5);

-- Copiando estrutura para tabela escolamusica.aluno
CREATE TABLE IF NOT EXISTS `aluno` (
  `idAluno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomeAluno` varchar(128) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `instrumento` varchar(64) DEFAULT NULL,
  `Funcionario_idFuncionario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idAluno`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_Aluno_Professor` (`Funcionario_idFuncionario`),
  CONSTRAINT `fk_Aluno_Professor` FOREIGN KEY (`Funcionario_idFuncionario`) REFERENCES `funcionario` (`idFuncionario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Copiando dados para a tabela escolamusica.aluno: ~3 rows (aproximadamente)
INSERT IGNORE INTO `aluno` (`idAluno`, `nomeAluno`, `telefone`, `email`, `instrumento`, `Funcionario_idFuncionario`) VALUES
	(1, 'Pedro Henrique', '11999990001', 'pedro@gmail.com', 'Bateria', 3),
	(2, 'Lucas Ferreira', '11999990002', 'lucas@gmail.com', 'Guitarra', 4),
	(3, 'Amanda Cristina', '11999990003', 'amanda@gmail.com', 'Canto', 5);

-- Copiando estrutura para tabela escolamusica.cobrancamensalidade
CREATE TABLE IF NOT EXISTS `cobrancamensalidade` (
  `idCobranca` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `valor` decimal(10,2) NOT NULL,
  `vencimento` date NOT NULL,
  `statusCobranca` enum('pendente','pago','atrasado') DEFAULT NULL,
  `Aluno_idAluno` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idCobranca`),
  KEY `fk_Cobranca_Aluno` (`Aluno_idAluno`),
  CONSTRAINT `fk_Cobranca_Aluno` FOREIGN KEY (`Aluno_idAluno`) REFERENCES `aluno` (`idAluno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Copiando dados para a tabela escolamusica.cobrancamensalidade: ~3 rows (aproximadamente)
INSERT IGNORE INTO `cobrancamensalidade` (`idCobranca`, `valor`, `vencimento`, `statusCobranca`, `Aluno_idAluno`) VALUES
	(1, 300.00, '2026-06-10', 'pago', 1),
	(2, 280.00, '2026-06-12', 'pendente', 2),
	(3, 250.00, '2026-06-15', 'atrasado', 3);

-- Copiando estrutura para tabela escolamusica.pagamento
CREATE TABLE IF NOT EXISTS `pagamento` (
  `idPagamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dataPagamento` date DEFAULT NULL,
  `valorPago` decimal(10,2) DEFAULT NULL,
  `formaPagamento` enum('PIX','CARTAO','DINHEIRO','BOLETO') DEFAULT NULL,
  `Cobranca_idCobranca` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idPagamento`),
  KEY `fk_Pagamento_Cobranca` (`Cobranca_idCobranca`),
  CONSTRAINT `fk_Pagamento_Cobranca` FOREIGN KEY (`Cobranca_idCobranca`) REFERENCES `cobrancamensalidade` (`idCobranca`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Copiando dados para a tabela escolamusica.pagamento: ~0 rows (aproximadamente)
INSERT IGNORE INTO `pagamento` (`idPagamento`, `dataPagamento`, `valorPago`, `formaPagamento`, `Cobranca_idCobranca`) VALUES
	(1, '2026-06-08', 300.00, 'PIX', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
