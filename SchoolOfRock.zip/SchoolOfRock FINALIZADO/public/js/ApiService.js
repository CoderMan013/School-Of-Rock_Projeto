/**
 * Centraliza a comunicação das telas com a API do SchoolOfRock.
 */
export default class ApiService {
    #token;

    constructor(token = null) {
        this.token = token;
    }

    get token() {
        return this.#token;
    }

    set token(value) {
        if (value !== null && typeof value !== "string") {
            throw new Error("O token deve ser um texto ou null.");
        }

        this.#token = value === null ? null : value.trim();
    }

    async simpleGet(uri) {
        return this.#requisitar("GET", uri, undefined, false);
    }

    async get(uri) {
        return this.#requisitar("GET", uri);
    }

    async getById(uri, id) {
        const endereco = this.#montarEndereco(uri, id);

        return this.#requisitar("GET", endereco);
    }

    async post(uri, jsonObject) {
        return this.#requisitar("POST", uri, jsonObject);
    }

    async put(uri, id, jsonObject) {
        const endereco = this.#montarEndereco(uri, id);

        return this.#requisitar("PUT", endereco, jsonObject);
    }

    async delete(uri, id) {
        const endereco = this.#montarEndereco(uri, id);

        return this.#requisitar("DELETE", endereco);
    }

    #montarEndereco(uri, id) {
        const idTexto = String(id);

        if (!/^[1-9]\d*$/.test(idTexto)) {
            throw new Error("O ID deve ser um número inteiro maior que zero.");
        }

        const base = uri.replace(/\/+$/, "");

        return `${base}/${idTexto}`;
    }

    async #requisitar(metodo, uri, dados = undefined, enviarToken = true) {
        const headers = {
            "Accept": "application/json"
        };

        if (enviarToken && this.#token) {
            headers["Authorization"] = `Bearer ${this.#token}`;
        }

        const configuracao = {
            method: metodo,
            headers: headers,
            cache: "no-store"
        };

        if (dados !== undefined) {
            headers["Content-Type"] = "application/json";
            configuracao.body = JSON.stringify(dados);
        }

        let response;
        let texto;

        try {
            response = await fetch(uri, configuracao);
            texto = await response.text();
        } catch {
            throw new Error(
                "Não foi possível comunicar com a API. "
                + "Verifique se o servidor está ligado e se o endereço está correto."
            );
        }

        let resultado = null;

        if (texto.trim() !== "") {
            try {
                resultado = JSON.parse(texto);
            } catch {
                const erro = new Error(
                    `A API retornou uma resposta que não é JSON (HTTP ${response.status}).`
                );

                erro.status = response.status;
                throw erro;
            }
        }

        if (!response.ok || resultado?.success === false) {
            const mensagem =
                resultado?.error?.message
                || resultado?.message
                || `Erro na requisição: HTTP ${response.status}.`;

            const erro = new Error(mensagem);

            erro.status = response.status;
            erro.dados = resultado;

            throw erro;
        }

        return resultado;
    }
}
