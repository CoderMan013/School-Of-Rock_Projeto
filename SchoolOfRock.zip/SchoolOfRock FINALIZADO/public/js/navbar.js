const LINKS = [
    { chave: "painel", rotulo: "Painel", href: "painel.html" },
    { chave: "cargos", rotulo: "Cargos", href: "cargos.html" },
    { chave: "funcionarios", rotulo: "Funcionários", href: "funcionarios.html" },
    { chave: "alunos", rotulo: "Alunos", href: "alunos.html" },
    { chave: "cobrancas", rotulo: "Mensalidades", href: "cobrancas.html" },
    { chave: "pagamentos", rotulo: "Pagamentos", href: "pagamentos.html" }
];

export function getFuncionarioLogado() {
    try {
        return JSON.parse(localStorage.getItem("sorFuncionario") || "null");
    } catch {
        return null;
    }
}

export function ehAdmin() {
    const funcionario = getFuncionarioLogado();

    return funcionario?.cargo?.nomeCargo === "Administrador";
}

export function ehProfessor() {
    const funcionario = getFuncionarioLogado();
    const cargo = funcionario?.cargo?.nomeCargo;

    return (
        cargo === "Professor de Bateria" ||
        cargo === "Professor de Guitarra" ||
        cargo === "Professor de Canto"
    );
}

export function ehRecepcionista() {
    const funcionario = getFuncionarioLogado();

    return funcionario?.cargo?.nomeCargo === "Recepcionista";
}

export function podeAcessar(pagina) {
    if (ehAdmin()) {
        return true;
    }

    if (ehRecepcionista()) {
        return (
            pagina === "painel" ||
            pagina === "alunos" ||
            pagina === "cobrancas" ||
            pagina === "pagamentos"
        );
    }

    if (ehProfessor()) {
        return (
            pagina === "painel" ||
            pagina === "alunos"
        );
    }

    return false;
}

export function podeCriar(pagina) {
    if (ehAdmin()) {
        return true;
    }

    if (ehRecepcionista()) {
        return (
            pagina === "alunos" ||
            pagina === "cobrancas" ||
            pagina === "pagamentos"
        );
    }

    return false;
}

export function podeEditar(pagina) {
    if (ehAdmin()) {
        return true;
    }

    if (ehRecepcionista()) {
        return (
            pagina === "alunos" ||
            pagina === "cobrancas" ||
            pagina === "pagamentos"
        );
    }

    if (ehProfessor()) {
        return pagina === "alunos";
    }

    return false;
}

export function podeExcluir(pagina) {
    return ehAdmin();
}

export function renderNavbar(paginaAtual) {
    const alvo = document.getElementById("navbar");

    if (!alvo) {
        return;
    }

    const nav = document.createElement("nav");
    nav.className = "navbar";
    nav.setAttribute("aria-label", "Navegação principal");

    const marca = document.createElement("a");
    marca.href = "painel.html";
    marca.className = "navbar-marca";
    marca.setAttribute("aria-label", "Ir para o painel");

    const logo = document.createElement("img");
    logo.src = "img/logo-school-of-rock.png";
    logo.alt = "SchoolOfRock";

    marca.appendChild(logo);

    const links = document.createElement("div");
    links.className = "navbar-links";

    LINKS
        .filter((link) => podeAcessar(link.chave))
        .forEach((link) => {
            const a = document.createElement("a");
            a.href = link.href;
            a.textContent = link.rotulo;

            if (link.chave === paginaAtual) {
                a.setAttribute("aria-current", "page");
            }

            links.appendChild(a);
        });

    const btnSair = document.createElement("button");
    btnSair.type = "button";
    btnSair.className = "navbar-sair";
    btnSair.textContent = "Sair";

    btnSair.addEventListener("click", async () => {
        const resultado = await Swal.fire({
            icon: "question",
            title: "Sair do SchoolOfRock?",
            showCancelButton: true,
            confirmButtonText: "Sair",
            cancelButtonText: "Cancelar",
            confirmButtonColor: "#e11d2e",
            background: "#1c1c1f",
            color: "#f3f1ea"
        });

        if (resultado.isConfirmed) {
            localStorage.removeItem("sorToken");
            localStorage.removeItem("sorFuncionario");
            window.location.replace("login.html");
        }
    });

    nav.append(marca, links, btnSair);
    alvo.replaceChildren(nav);
}