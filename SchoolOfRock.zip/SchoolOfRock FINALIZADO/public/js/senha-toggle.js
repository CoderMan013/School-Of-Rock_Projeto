document.querySelectorAll(".botao-olho").forEach((botao) => {
    botao.addEventListener("click", () => {
        const alvo = document.getElementById(botao.dataset.alvo);
        const mostrando = alvo.type === "text";
        alvo.type = mostrando ? "password" : "text";
        botao.classList.toggle("ativo", !mostrando);
        botao.setAttribute("aria-label", mostrando ? "Mostrar senha" : "Ocultar senha");
    });
});