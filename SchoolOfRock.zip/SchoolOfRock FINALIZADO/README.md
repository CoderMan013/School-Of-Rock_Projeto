# SchoolOfRock

API REST (PHP + Slim Framework, arquitetura MVCS) e painel web para gerenciar
uma escola de música, com login e autenticação via JWT.

## Estrutura

- `database/escolamusica.sql` — script do banco (tabelas cargo, funcionario,
  aluno, cobrancamensalidade, pagamento).
- `src/api/` — models, DAOs, services, controllers, middlewares e rotas.
- `public/` — `index.php` (front controller da API) e as telas HTML do painel
  (login, cadastro e CRUD de cada entidade), com SweetAlert2 para mensagens.

## Como rodar

1. Importe `database/escolamusica.sql` no MySQL/MariaDB.
2. Ajuste as credenciais de conexão em `public/index.php` se necessário
   (por padrão: host `localhost`, usuário `root`, sem senha, banco
   `escolamusica`).
3. Na raiz do projeto, rode:
   ```
   php -S localhost:8080 -t public
   ```
4. Acesse `http://localhost:8080/login.html`.
5. Não tem uma conta ainda? Use `http://localhost:8080/cadastro.html` para criar
   um novo funcionário (rota pública, não exige login).

## Login de teste

Todos os funcionários do script SQL usam a senha `123456`, por exemplo:

- `marcos@escolamusica.com` (Administrador)
- `juliana@escolamusica.com` (Recepcionista)
- `ricardo@escolamusica.com` (Professor de Bateria)

## Observação sobre as senhas

O arquivo `escolamusica.sql` enviado originalmente guardava a senha como texto
puro (`123456`). A API usa `password_hash()`/`password_verify()` do PHP, então
o script incluído aqui já traz a senha como hash bcrypt — o valor em texto
para login continua sendo `123456`.

## Autenticação

Toda rota, exceto `POST /login`, `POST /cadastro` e `GET /cargos/publico`,
exige o cabeçalho:

```
Authorization: Bearer <token>
```

O token é obtido no login e expira em 1 hora.
