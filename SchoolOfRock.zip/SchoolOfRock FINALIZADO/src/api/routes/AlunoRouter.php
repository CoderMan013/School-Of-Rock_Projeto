<?php

namespace Api\Routes;

use Slim\App;
use Api\Controllers\AlunoController;
use Api\Middlewares\Aluno\ValidateAlunoBody;
use Api\Middlewares\Aluno\ValidateAlunoId;
use Api\Middlewares\Funcionario\ValidateFuncionarioToken;

class AlunoRouter
{
    private App $app;

    public function __construct(App $app)
    {
        $this->app = $app;
    }

    public function setupRoutes(): void
    {
        $this->app->post(
            '/alunos',
            [AlunoController::class, 'createController']
        )
            ->add(ValidateAlunoBody::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/alunos',
            [AlunoController::class, 'findAllController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/alunos/count',
            [AlunoController::class, 'countController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/alunos/{idAluno}',
            [AlunoController::class, 'findByIdController']
        )
            ->add(ValidateAlunoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->put(
            '/alunos/{idAluno}',
            [AlunoController::class, 'updateController']
        )
            ->add(ValidateAlunoBody::class)
            ->add(ValidateAlunoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->delete(
            '/alunos/{idAluno}',
            [AlunoController::class, 'deleteController']
        )
            ->add(ValidateAlunoId::class)
            ->add(ValidateFuncionarioToken::class);
    }
}
