<?php

namespace Api\Routes;

use Slim\App;
use Api\Controllers\CobrancaMensalidadeController;
use Api\Middlewares\Cobranca\ValidateCobrancaBody;
use Api\Middlewares\Cobranca\ValidateCobrancaId;
use Api\Middlewares\Funcionario\ValidateFuncionarioToken;

class CobrancaMensalidadeRouter
{
    private App $app;

    public function __construct(App $app)
    {
        $this->app = $app;
    }

    public function setupRoutes(): void
    {
        $this->app->post(
            '/cobrancas',
            [CobrancaMensalidadeController::class, 'createController']
        )
            ->add(ValidateCobrancaBody::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cobrancas',
            [CobrancaMensalidadeController::class, 'findAllController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cobrancas/count',
            [CobrancaMensalidadeController::class, 'countController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cobrancas/{idCobranca}',
            [CobrancaMensalidadeController::class, 'findByIdController']
        )
            ->add(ValidateCobrancaId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->put(
            '/cobrancas/{idCobranca}',
            [CobrancaMensalidadeController::class, 'updateController']
        )
            ->add(ValidateCobrancaBody::class)
            ->add(ValidateCobrancaId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->delete(
            '/cobrancas/{idCobranca}',
            [CobrancaMensalidadeController::class, 'deleteController']
        )
            ->add(ValidateCobrancaId::class)
            ->add(ValidateFuncionarioToken::class);
    }
}
