<?php

namespace Api\Routes;

use Slim\App;
use Api\Controllers\FuncionarioController;
use Api\Middlewares\Funcionario\ValidateFuncionarioBody;
use Api\Middlewares\Funcionario\ValidateFuncionarioId;
use Api\Middlewares\Funcionario\ValidateFuncionarioLoginBody;
use Api\Middlewares\Funcionario\ValidateFuncionarioToken;

/**
 * Registra as rotas de funcionários e a rota pública de login.
 */
class FuncionarioRouter
{
    private App $app;

    public function __construct(App $app)
    {
        $this->app = $app;
    }

    public function setupRoutes(): void
    {
        /**
         * POST /login
         * Rota pública: confere as credenciais e retorna o JWT.
         */
        $this->app->post(
            '/login',
            [FuncionarioController::class, 'loginController']
        )
            ->add(ValidateFuncionarioLoginBody::class);

        /**
         * POST /cadastro
         * Rota pública: cria a conta de um novo funcionário, sem exigir login prévio.
         */
        $this->app->post(
            '/cadastro',
            [FuncionarioController::class, 'createController']
        )
            ->add(ValidateFuncionarioBody::class);

        $this->app->post(
            '/funcionarios',
            [FuncionarioController::class, 'createController']
        )
            ->add(ValidateFuncionarioBody::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/funcionarios',
            [FuncionarioController::class, 'findAllController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/funcionarios/count',
            [FuncionarioController::class, 'countController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/funcionarios/{idFuncionario}',
            [FuncionarioController::class, 'findByIdController']
        )
            ->add(ValidateFuncionarioId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->put(
            '/funcionarios/{idFuncionario}',
            [FuncionarioController::class, 'updateController']
        )
            ->add(ValidateFuncionarioBody::class)
            ->add(ValidateFuncionarioId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->delete(
            '/funcionarios/{idFuncionario}',
            [FuncionarioController::class, 'deleteController']
        )
            ->add(ValidateFuncionarioId::class)
            ->add(ValidateFuncionarioToken::class);
    }
}
