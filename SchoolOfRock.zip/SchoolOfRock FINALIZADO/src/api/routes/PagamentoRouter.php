<?php

namespace Api\Routes;

use Slim\App;
use Api\Controllers\PagamentoController;
use Api\Middlewares\Pagamento\ValidatePagamentoBody;
use Api\Middlewares\Pagamento\ValidatePagamentoId;
use Api\Middlewares\Funcionario\ValidateFuncionarioToken;

class PagamentoRouter
{
    private App $app;

    public function __construct(App $app)
    {
        $this->app = $app;
    }

    public function setupRoutes(): void
    {
        $this->app->post(
            '/pagamentos',
            [PagamentoController::class, 'createController']
        )
            ->add(ValidatePagamentoBody::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/pagamentos',
            [PagamentoController::class, 'findAllController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/pagamentos/count',
            [PagamentoController::class, 'countController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/pagamentos/{idPagamento}',
            [PagamentoController::class, 'findByIdController']
        )
            ->add(ValidatePagamentoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->put(
            '/pagamentos/{idPagamento}',
            [PagamentoController::class, 'updateController']
        )
            ->add(ValidatePagamentoBody::class)
            ->add(ValidatePagamentoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->delete(
            '/pagamentos/{idPagamento}',
            [PagamentoController::class, 'deleteController']
        )
            ->add(ValidatePagamentoId::class)
            ->add(ValidateFuncionarioToken::class);
    }
}
