<?php

namespace Api\Routes;

use Slim\App;
use Api\Controllers\CargoController;
use Api\Middlewares\Cargo\ValidateCargoBody;
use Api\Middlewares\Cargo\ValidateCargoId;
use Api\Middlewares\Funcionario\ValidateFuncionarioToken;

/**
 * Registra e protege as rotas de cargos.
 * Todas exigem um token JWT válido, exceto a listagem pública usada no cadastro.
 */
class CargoRouter
{
    private App $app;

    public function __construct(App $app)
    {
        $this->app = $app;
    }

    public function setupRoutes(): void
    {
        /**
         * GET /cargos/publico
         * Rota pública: lista os cargos para preencher o formulário de cadastro,
         * antes de o novo funcionário ter um token.
         */
        $this->app->get(
            '/cargos/publico',
            [CargoController::class, 'findAllController']
        );

        $this->app->post(
            '/cargos',
            [CargoController::class, 'createController']
        )
            ->add(ValidateCargoBody::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cargos',
            [CargoController::class, 'findAllController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cargos/count',
            [CargoController::class, 'countController']
        )
            ->add(ValidateFuncionarioToken::class);

        $this->app->get(
            '/cargos/{idCargo}',
            [CargoController::class, 'findByIdController']
        )
            ->add(ValidateCargoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->put(
            '/cargos/{idCargo}',
            [CargoController::class, 'updateController']
        )
            ->add(ValidateCargoBody::class)
            ->add(ValidateCargoId::class)
            ->add(ValidateFuncionarioToken::class);

        $this->app->delete(
            '/cargos/{idCargo}',
            [CargoController::class, 'deleteController']
        )
            ->add(ValidateCargoId::class)
            ->add(ValidateFuncionarioToken::class);
    }
}
