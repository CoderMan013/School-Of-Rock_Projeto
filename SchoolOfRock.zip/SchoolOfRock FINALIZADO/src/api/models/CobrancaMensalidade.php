<?php

namespace Api\Models;

use InvalidArgumentException;
use JsonSerializable;

/**
 * Representa uma cobrança de mensalidade vinculada a um aluno.
 */
class CobrancaMensalidade implements JsonSerializable
{
    public const STATUS_PERMITIDOS = ['pendente', 'pago', 'atrasado'];

    private ?int $idCobranca = null;
    private float $valor = 0.0;
    private ?string $vencimento = null;
    private ?string $statusCobranca = 'pendente';
    private Aluno $aluno;

    public function __construct()
    {
        $this->aluno = new Aluno();
    }

    public function getIdCobranca(): ?int
    {
        return $this->idCobranca;
    }

    public function setIdCobranca(int $idCobranca): void
    {
        if ($idCobranca <= 0) {
            throw new InvalidArgumentException(
                'O ID da cobrança deve ser maior que zero.'
            );
        }

        $this->idCobranca = $idCobranca;
    }

    public function getValor(): float
    {
        return $this->valor;
    }

    public function setValor(float $valor): void
    {
        if (!is_finite($valor) || $valor <= 0 || $valor > 99999999.99) {
            throw new InvalidArgumentException(
                'O valor deve ser maior que zero e no máximo 99999999.99.'
            );
        }

        $valorArredondado = round($valor, 2);

        if (abs($valor - $valorArredondado) > 0.000001) {
            throw new InvalidArgumentException(
                'O valor deve ter no máximo duas casas decimais.'
            );
        }

        $this->valor = $valorArredondado;
    }

    public function getVencimento(): ?string
    {
        return $this->vencimento;
    }

    /**
     * Define a data de vencimento no formato YYYY-MM-DD.
     */
    public function setVencimento(string $vencimento): void
    {
        $vencimento = trim($vencimento);

        $data = \DateTime::createFromFormat('Y-m-d', $vencimento);

        if (!$data || $data->format('Y-m-d') !== $vencimento) {
            throw new InvalidArgumentException(
                'Informe o vencimento no formato AAAA-MM-DD.'
            );
        }

        $this->vencimento = $vencimento;
    }

    public function getStatusCobranca(): ?string
    {
        return $this->statusCobranca;
    }

    public function setStatusCobranca(?string $statusCobranca): void
    {
        if ($statusCobranca === null) {
            $this->statusCobranca = null;
            return;
        }

        if (!in_array($statusCobranca, self::STATUS_PERMITIDOS, true)) {
            throw new InvalidArgumentException(
                'O status da cobrança deve ser "pendente", "pago" ou "atrasado".'
            );
        }

        $this->statusCobranca = $statusCobranca;
    }

    public function getAluno(): Aluno
    {
        return $this->aluno;
    }

    public function setAluno(Aluno $aluno): void
    {
        $idAluno = $aluno->getIdAluno();

        if ($idAluno === null || $idAluno <= 0) {
            throw new InvalidArgumentException(
                'O aluno relacionado deve possuir um ID válido.'
            );
        }

        $this->aluno = $aluno;
    }

    public function jsonSerialize(): array
    {
        return [
            'idCobranca' => $this->getIdCobranca(),
            'valor' => $this->getValor(),
            'vencimento' => $this->getVencimento(),
            'statusCobranca' => $this->getStatusCobranca(),
            'aluno' => $this->getAluno()
        ];
    }
}
