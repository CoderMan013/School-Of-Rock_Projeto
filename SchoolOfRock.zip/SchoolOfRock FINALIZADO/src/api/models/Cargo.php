<?php

namespace Api\Models;

use InvalidArgumentException;
use JsonSerializable;

/**
 * Representa um cargo da escola de música.
 *
 * Corresponde à tabela cargo do banco escolamusica.
 */
class Cargo implements JsonSerializable
{
    private ?int $idCargo = null;
    private ?string $nomeCargo = null;

    public function getIdCargo(): ?int
    {
        return $this->idCargo;
    }

    public function setIdCargo(int $idCargo): void
    {
        if ($idCargo <= 0) {
            throw new InvalidArgumentException(
                'O ID do cargo deve ser maior que zero.'
            );
        }

        $this->idCargo = $idCargo;
    }

    public function getNomeCargo(): ?string
    {
        return $this->nomeCargo;
    }

    public function setNomeCargo(string $nomeCargo): void
    {
        $nome = trim($nomeCargo);
        $tamanho = mb_strlen($nome, 'UTF-8');

        if ($tamanho < 3 || $tamanho > 64) {
            throw new InvalidArgumentException(
                'O nome do cargo deve ter entre 3 e 64 caracteres.'
            );
        }

        $this->nomeCargo = $nome;
    }

    public function jsonSerialize(): array
    {
        return [
            'idCargo' => $this->getIdCargo(),
            'nomeCargo' => $this->getNomeCargo()
        ];
    }
}
