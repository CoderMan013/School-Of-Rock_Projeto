<?php

namespace Api\Models;

use InvalidArgumentException;
use JsonSerializable;

/**
 * Representa um aluno da escola de música.
 *
 * Todo aluno está vinculado a um funcionário (o professor responsável).
 */
class Aluno implements JsonSerializable
{
    private ?int $idAluno = null;
    private ?string $nomeAluno = null;
    private ?string $telefone = null;
    private ?string $email = null;
    private ?string $instrumento = null;
    private Funcionario $funcionario;

    public function __construct()
    {
        $this->funcionario = new Funcionario();
    }

    public function getIdAluno(): ?int
    {
        return $this->idAluno;
    }

    public function setIdAluno(int $idAluno): void
    {
        if ($idAluno <= 0) {
            throw new InvalidArgumentException(
                'O ID do aluno deve ser maior que zero.'
            );
        }

        $this->idAluno = $idAluno;
    }

    public function getNomeAluno(): ?string
    {
        return $this->nomeAluno;
    }

    public function setNomeAluno(string $nomeAluno): void
    {
        $nome = trim($nomeAluno);
        $tamanho = mb_strlen($nome, 'UTF-8');

        if ($tamanho < 3 || $tamanho > 128) {
            throw new InvalidArgumentException(
                'O nome do aluno deve ter entre 3 e 128 caracteres.'
            );
        }

        $this->nomeAluno = $nome;
    }

    public function getTelefone(): ?string
    {
        return $this->telefone;
    }

    public function setTelefone(?string $telefone): void
    {
        if ($telefone === null || trim($telefone) === '') {
            $this->telefone = null;
            return;
        }

        $telefone = trim($telefone);

        if (mb_strlen($telefone, 'UTF-8') > 20) {
            throw new InvalidArgumentException(
                'O telefone deve ter no máximo 20 caracteres.'
            );
        }

        $this->telefone = $telefone;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(?string $email): void
    {
        if ($email === null || trim($email) === '') {
            $this->email = null;
            return;
        }

        $email = strtolower(trim($email));

        if (
            mb_strlen($email, 'UTF-8') > 64
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            throw new InvalidArgumentException(
                'Informe um e-mail válido com no máximo 64 caracteres.'
            );
        }

        $this->email = $email;
    }

    public function getInstrumento(): ?string
    {
        return $this->instrumento;
    }

    public function setInstrumento(?string $instrumento): void
    {
        if ($instrumento === null || trim($instrumento) === '') {
            $this->instrumento = null;
            return;
        }

        $instrumento = trim($instrumento);

        if (mb_strlen($instrumento, 'UTF-8') > 64) {
            throw new InvalidArgumentException(
                'O instrumento deve ter no máximo 64 caracteres.'
            );
        }

        $this->instrumento = $instrumento;
    }

    public function getFuncionario(): Funcionario
    {
        return $this->funcionario;
    }

    public function setFuncionario(Funcionario $funcionario): void
    {
        $idFuncionario = $funcionario->getIdFuncionario();

        if ($idFuncionario === null || $idFuncionario <= 0) {
            throw new InvalidArgumentException(
                'O professor responsável deve possuir um ID válido.'
            );
        }

        $this->funcionario = $funcionario;
    }

    public function jsonSerialize(): array
    {
        return [
            'idAluno' => $this->getIdAluno(),
            'nomeAluno' => $this->getNomeAluno(),
            'telefone' => $this->getTelefone(),
            'email' => $this->getEmail(),
            'instrumento' => $this->getInstrumento(),
            'funcionario' => $this->getFuncionario()
        ];
    }
}
