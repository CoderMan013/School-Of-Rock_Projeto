<?php

namespace Api\Models;

use InvalidArgumentException;
use JsonSerializable;

/**
 * Representa o pagamento de uma cobrança de mensalidade.
 */
class Pagamento implements JsonSerializable
{
    public const FORMAS_PERMITIDAS = ['PIX', 'CARTAO', 'DINHEIRO', 'BOLETO'];

    private ?int $idPagamento = null;
    private ?string $dataPagamento = null;
    private ?float $valorPago = null;
    private ?string $formaPagamento = null;
    private CobrancaMensalidade $cobranca;

    public function __construct()
    {
        $this->cobranca = new CobrancaMensalidade();
    }

    public function getIdPagamento(): ?int
    {
        return $this->idPagamento;
    }

    public function setIdPagamento(int $idPagamento): void
    {
        if ($idPagamento <= 0) {
            throw new InvalidArgumentException(
                'O ID do pagamento deve ser maior que zero.'
            );
        }

        $this->idPagamento = $idPagamento;
    }

    public function getDataPagamento(): ?string
    {
        return $this->dataPagamento;
    }

    public function setDataPagamento(?string $dataPagamento): void
    {
        if ($dataPagamento === null || trim($dataPagamento) === '') {
            $this->dataPagamento = null;
            return;
        }

        $dataPagamento = trim($dataPagamento);

        $data = \DateTime::createFromFormat('Y-m-d', $dataPagamento);

        if (!$data || $data->format('Y-m-d') !== $dataPagamento) {
            throw new InvalidArgumentException(
                'Informe a data de pagamento no formato AAAA-MM-DD.'
            );
        }

        $this->dataPagamento = $dataPagamento;
    }

    public function getValorPago(): ?float
    {
        return $this->valorPago;
    }

    public function setValorPago(?float $valorPago): void
    {
        if ($valorPago === null) {
            $this->valorPago = null;
            return;
        }

        if (!is_finite($valorPago) || $valorPago <= 0 || $valorPago > 99999999.99) {
            throw new InvalidArgumentException(
                'O valor pago deve ser maior que zero e no máximo 99999999.99.'
            );
        }

        $this->valorPago = round($valorPago, 2);
    }

    public function getFormaPagamento(): ?string
    {
        return $this->formaPagamento;
    }

    public function setFormaPagamento(?string $formaPagamento): void
    {
        if ($formaPagamento === null) {
            $this->formaPagamento = null;
            return;
        }

        if (!in_array($formaPagamento, self::FORMAS_PERMITIDAS, true)) {
            throw new InvalidArgumentException(
                'A forma de pagamento deve ser PIX, CARTAO, DINHEIRO ou BOLETO.'
            );
        }

        $this->formaPagamento = $formaPagamento;
    }

    public function getCobranca(): CobrancaMensalidade
    {
        return $this->cobranca;
    }

    public function setCobranca(CobrancaMensalidade $cobranca): void
    {
        $idCobranca = $cobranca->getIdCobranca();

        if ($idCobranca === null || $idCobranca <= 0) {
            throw new InvalidArgumentException(
                'A cobrança relacionada deve possuir um ID válido.'
            );
        }

        $this->cobranca = $cobranca;
    }

    public function jsonSerialize(): array
    {
        return [
            'idPagamento' => $this->getIdPagamento(),
            'dataPagamento' => $this->getDataPagamento(),
            'valorPago' => $this->getValorPago(),
            'formaPagamento' => $this->getFormaPagamento(),
            'cobranca' => $this->getCobranca()
        ];
    }
}
