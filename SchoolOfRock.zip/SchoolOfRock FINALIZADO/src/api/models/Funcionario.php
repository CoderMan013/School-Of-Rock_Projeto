<?php

namespace Api\Models;

use InvalidArgumentException;
use JsonSerializable;

/**
 * Representa um funcionário da escola de música.
 *
 * Também é a conta usada para autenticação (login com e-mail e senha).
 * A senha armazenada neste objeto é sempre um hash bcrypt.
 */
class Funcionario implements JsonSerializable
{
    private ?int $idFuncionario = null;
    private ?string $nomeFuncionario = null;
    private string $email = '';
    private ?string $senhaHash = null;
    private bool $recebeValeTransporte = false;
    private Cargo $cargo;

    public function __construct()
    {
        $this->cargo = new Cargo();
    }

    public function getIdFuncionario(): ?int
    {
        return $this->idFuncionario;
    }

    public function setIdFuncionario(int $idFuncionario): void
    {
        if ($idFuncionario <= 0) {
            throw new InvalidArgumentException(
                'O ID do funcionário deve ser maior que zero.'
            );
        }

        $this->idFuncionario = $idFuncionario;
    }

    public function getNomeFuncionario(): ?string
    {
        return $this->nomeFuncionario;
    }

    public function setNomeFuncionario(string $nomeFuncionario): void
    {
        $nome = trim($nomeFuncionario);
        $tamanho = mb_strlen($nome, 'UTF-8');

        if ($tamanho < 3 || $tamanho > 128) {
            throw new InvalidArgumentException(
                'O nome do funcionário deve ter entre 3 e 128 caracteres.'
            );
        }

        $this->nomeFuncionario = $nome;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function setEmail(string $email): void
    {
        $email = strtolower(trim($email));

        if (
            mb_strlen($email, 'UTF-8') > 64
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            throw new InvalidArgumentException(
                'Informe um e-mail válido com no máximo 64 caracteres.'
            );
        }

        $this->email = $email;
    }

    /**
     * Recebe uma senha em texto puro e gera o hash bcrypt.
     * Utilizado ao cadastrar ou trocar a senha.
     */
    public function setSenha(string $senha): void
    {
        if (mb_strlen($senha, 'UTF-8') < 6) {
            throw new InvalidArgumentException(
                'A senha deve ter pelo menos 6 caracteres.'
            );
        }

        if (strlen($senha) > 72) {
            throw new InvalidArgumentException(
                'A senha deve ocupar no máximo 72 bytes.'
            );
        }

        $this->senhaHash = password_hash($senha, PASSWORD_BCRYPT);
    }

    public function getSenhaHash(): ?string
    {
        return $this->senhaHash;
    }

    /**
     * Carrega um hash já salvo no banco, sem gerar outro hash sobre ele.
     */
    public function setSenhaHash(string $senhaHash): void
    {
        $informacoes = password_get_info($senhaHash);

        if (
            $informacoes['algoName'] === 'unknown'
            || strlen($senhaHash) > 64
        ) {
            throw new InvalidArgumentException(
                'O hash da senha é inválido.'
            );
        }

        $this->senhaHash = $senhaHash;
    }

    public function verificarSenha(string $senha): bool
    {
        if ($this->senhaHash === null) {
            return false;
        }

        if (strlen($senha) > 72) {
            return false;
        }

        return password_verify($senha, $this->senhaHash);
    }

    public function getRecebeValeTransporte(): bool
    {
        return $this->recebeValeTransporte;
    }

    public function setRecebeValeTransporte(bool $recebeValeTransporte): void
    {
        $this->recebeValeTransporte = $recebeValeTransporte;
    }

    public function getCargo(): Cargo
    {
        return $this->cargo;
    }

    public function setCargo(Cargo $cargo): void
    {
        $idCargo = $cargo->getIdCargo();

        if ($idCargo === null || $idCargo <= 0) {
            throw new InvalidArgumentException(
                'O cargo relacionado deve possuir um ID válido.'
            );
        }

        $this->cargo = $cargo;
    }

    /**
     * A senha e seu hash nunca são enviados no JSON.
     */
    public function jsonSerialize(): array
    {
        return [
            'idFuncionario' => $this->getIdFuncionario(),
            'nomeFuncionario' => $this->getNomeFuncionario(),
            'email' => $this->getEmail(),
            'recebeValeTransporte' => $this->getRecebeValeTransporte(),
            'cargo' => $this->getCargo()
        ];
    }
}
