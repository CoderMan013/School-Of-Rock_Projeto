<?php

namespace Api\Server;

use Slim\App;
use Slim\Psr7\Response;
use Slim\Exception\HttpException;
use Slim\Exception\HttpMethodNotAllowedException;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Server\RequestHandlerInterface;

use Api\Http\ErrorResponse;
use Api\Routes\CargoRouter;
use Api\Routes\FuncionarioRouter;
use Api\Routes\AlunoRouter;
use Api\Routes\CobrancaMensalidadeRouter;
use Api\Routes\PagamentoRouter;

use InvalidArgumentException;
use Throwable;

/**
 * Configura as rotas, os middlewares e o tratamento de erros da aplicação.
 */
class Server
{
    private App $app;

    private CargoRouter $cargoRouter;
    private FuncionarioRouter $funcionarioRouter;
    private AlunoRouter $alunoRouter;
    private CobrancaMensalidadeRouter $cobrancaRouter;
    private PagamentoRouter $pagamentoRouter;

    public function __construct(
        App $app,
        CargoRouter $cargoRouter,
        FuncionarioRouter $funcionarioRouter,
        AlunoRouter $alunoRouter,
        CobrancaMensalidadeRouter $cobrancaRouter,
        PagamentoRouter $pagamentoRouter
    ) {
        $this->app = $app;

        $this->cargoRouter = $cargoRouter;
        $this->funcionarioRouter = $funcionarioRouter;
        $this->alunoRouter = $alunoRouter;
        $this->cobrancaRouter = $cobrancaRouter;
        $this->pagamentoRouter = $pagamentoRouter;

        $this->setupRoutes();
        $this->setupMiddlewares();
        $this->setupErrorHandling();
        $this->setupCors();
    }

    private function setupRoutes(): void
    {
        $this->cargoRouter->setupRoutes();
        $this->funcionarioRouter->setupRoutes();
        $this->alunoRouter->setupRoutes();
        $this->cobrancaRouter->setupRoutes();
        $this->pagamentoRouter->setupRoutes();

        $this->app->get(
            '/',
            function (
                ServerRequestInterface $request,
                ResponseInterface $response
            ): ResponseInterface {
                return $response
                    ->withHeader('Location', '/login.html')
                    ->withStatus(302);
            }
        );
    }

    private function setupMiddlewares(): void
    {
        $this->app->addBodyParsingMiddleware();
        $this->app->addRoutingMiddleware();
    }

    private function setupCors(): void
    {
        $this->app->add(
            function (
                ServerRequestInterface $request,
                RequestHandlerInterface $handler
            ): ResponseInterface {
                if ($request->getMethod() === 'OPTIONS') {
                    $response = new Response(204);
                } else {
                    $response = $handler->handle($request);
                }

                return $response
                    ->withHeader('Access-Control-Allow-Origin', '*')
                    ->withHeader(
                        'Access-Control-Allow-Methods',
                        'GET, POST, PUT, DELETE, OPTIONS'
                    )
                    ->withHeader(
                        'Access-Control-Allow-Headers',
                        'Content-Type, Authorization'
                    );
            }
        );
    }

    private function setupErrorHandling(): void
    {
        $errorMiddleware = $this->app->addErrorMiddleware(false, true, true);

        $errorMiddleware->setDefaultErrorHandler(
            function (
                ServerRequestInterface $request,
                Throwable $exception
            ): ResponseInterface {
                $response = new Response();

                $status = 500;
                $message = 'Erro interno do servidor';
                $error = ['message' => 'Não foi possível concluir a operação.'];

                if ($exception instanceof ErrorResponse) {
                    $status = $exception->getHttpCode();
                    $message = $exception->getMessage();
                    $error = $exception->getError() ?? (object) [];

                } elseif ($exception instanceof InvalidArgumentException) {
                    $status = 400;
                    $message = 'Erro na validação de dados';
                    $error = ['message' => $exception->getMessage()];

                } elseif ($exception instanceof HttpException) {
                    $status = $exception->getCode();

                    if ($status === 404) {
                        $message = 'Rota não encontrada';
                        $error = ['message' => 'Verifique o endereço solicitado.'];

                    } elseif ($status === 405) {
                        $message = 'Método HTTP não permitido';
                        $error = ['message' => 'Esse método não está disponível para a rota.'];

                    } else {
                        $message = 'Erro na requisição';
                        $error = ['message' => $exception->getMessage()];
                    }

                    if ($exception instanceof HttpMethodNotAllowedException) {
                        $response = $response->withHeader(
                            'Allow',
                            implode(', ', $exception->getAllowedMethods())
                        );
                    }
                }

                if ($status >= 500) {
                    error_log((string) $exception);
                }

                $payload = [
                    'success' => false,
                    'message' => $message,
                    'error' => $error
                ];

                $response->getBody()->write(
                    json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
                );

                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus($status);
            }
        );
    }

    public function run(): void
    {
        $this->app->run();
    }
}
