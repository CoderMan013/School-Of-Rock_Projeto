<?php

namespace Api\Http;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use InvalidArgumentException;
use RuntimeException;
use UnexpectedValueException;
use stdClass;

class TokenJWT
{
    private const KEY = '20b5db93928426255901dc6142e5fd36399c1cad7beb40293a9dad17b4986f76';

    private const ALGORITHM = 'HS256';

    private string $iss = 'http://localhost:8080';
    private string $aud = 'schoolofrock-painel';
    private string $sub = 'acesso_sistema';

    private int $duration = 3600;

    private ?stdClass $payload = null;

    public function __construct()
    {
        if (strlen(self::KEY) < 32) {
            throw new RuntimeException(
                'Configure a chave secreta em TokenJWT.php.'
            );
        }
    }

    public function gerarToken(stdClass $claims): string
    {
        if (
            !isset($claims->idFuncionario)
            || !is_int($claims->idFuncionario)
            || $claims->idFuncionario <= 0
        ) {
            throw new InvalidArgumentException(
                'Informe um ID de funcionário válido para gerar o token.'
            );
        }

        if (
            !isset($claims->nomeFuncionario, $claims->email)
            || !is_string($claims->nomeFuncionario)
            || !is_string($claims->email)
        ) {
            throw new InvalidArgumentException(
                'Informe nome e e-mail do funcionário autenticado.'
            );
        }

        $agora = time();

        $payload = [
            'iss' => $this->iss,
            'aud' => $this->aud,
            'sub' => $this->sub,

            'iat' => $agora,
            'nbf' => $agora,
            'exp' => $agora + $this->duration,

            'jti' => bin2hex(random_bytes(16)),

            // Nunca incluir a senha nem seu hash.
            'funcionario' => [
                'idFuncionario' => $claims->idFuncionario,
                'nomeFuncionario' => $claims->nomeFuncionario,
                'email' => $claims->email,
                'cargo' => $claims->cargo ?? null
            ]
        ];

        return JWT::encode(
            $payload,
            self::KEY,
            self::ALGORITHM
        );
    }

    public function validateToken(string $stringToken): bool
    {
        $this->payload = null;

        $token = trim($stringToken);

        if (str_starts_with($token, 'Bearer ')) {
            $token = trim(substr($token, 7));
        }

        if ($token === '') {
            return false;
        }

        try {
            $payload = JWT::decode(
                $token,
                new Key(self::KEY, self::ALGORITHM)
            );

            if (
                ($payload->iss ?? null) !== $this->iss
                || ($payload->aud ?? null) !== $this->aud
                || ($payload->sub ?? null) !== $this->sub
            ) {
                return false;
            }

            if (
                !isset($payload->iat, $payload->nbf, $payload->exp)
                || !is_int($payload->iat)
                || !is_int($payload->nbf)
                || !is_int($payload->exp)
                || $payload->exp <= time()
            ) {
                return false;
            }

            if (
                !isset($payload->funcionario)
                || !($payload->funcionario instanceof stdClass)
            ) {
                return false;
            }

            $funcionario = $payload->funcionario;

            if (
                !isset($funcionario->idFuncionario)
                || !is_int($funcionario->idFuncionario)
                || $funcionario->idFuncionario <= 0
            ) {
                return false;
            }

            $this->payload = $payload;

            return true;
        } catch (UnexpectedValueException | \LogicException $exception) {
            return false;
        }
    }

    public function getPayload(): ?stdClass
    {
        return $this->payload;
    }

    public function limparPayload(): void
    {
        $this->payload = null;
    }
}
