<?php

namespace Api\Middlewares\Cobranca;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use stdClass;

class ValidateCobrancaBody implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um corpo JSON válido na requisição.']
            );
        }

        if (!($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O corpo da requisição deve ser um objeto JSON.']
            );
        }

        if (
            !isset($objPHP->cobranca)
            || !($objPHP->cobranca instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "cobranca" é obrigatório e deve ser um objeto.']
            );
        }

        $cobranca = $objPHP->cobranca;

        if (!isset($cobranca->valor) || !is_numeric($cobranca->valor)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "valor" é obrigatório e deve ser um número.']
            );
        }

        if (
            !isset($cobranca->vencimento)
            || !is_string($cobranca->vencimento)
            || trim($cobranca->vencimento) === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "vencimento" é obrigatório no formato AAAA-MM-DD.']
            );
        }

        if (
            !isset($cobranca->aluno)
            || !($cobranca->aluno instanceof stdClass)
            || !isset($cobranca->aluno->idAluno)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "aluno" com "idAluno" é obrigatório.']
            );
        }

        return $handler->handle($request);
    }
}
