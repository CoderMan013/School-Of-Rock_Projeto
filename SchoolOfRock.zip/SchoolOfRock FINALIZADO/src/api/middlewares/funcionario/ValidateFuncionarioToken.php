<?php

namespace Api\Middlewares\Funcionario;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use Api\Http\TokenJWT;

/**
 * Valida o token JWT recebido na requisição.
 *
 * Utilizado em todos os recursos protegidos da API.
 */
class ValidateFuncionarioToken implements MiddlewareInterface
{
    private TokenJWT $jwt;

    public function __construct(TokenJWT $jwt)
    {
        $this->jwt = $jwt;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        $authorization = trim($request->getHeaderLine('Authorization'));

        if ($authorization === '') {
            throw new ErrorResponse(
                401,
                'Acesso não autorizado',
                ['message' => 'Token de autenticação não informado.']
            );
        }

        if (preg_match('/^Bearer\s+(\S+)$/i', $authorization, $partes) !== 1) {
            throw new ErrorResponse(
                401,
                'Acesso não autorizado',
                ['message' => 'Use o cabeçalho Authorization no formato Bearer TOKEN.']
            );
        }

        $token = $partes[1];

        if (!$this->jwt->validateToken($token)) {
            throw new ErrorResponse(
                401,
                'Acesso não autorizado',
                ['message' => 'Token inválido ou expirado. Faça login novamente.']
            );
        }

        $payload = $this->jwt->getPayload();

        if ($payload === null) {
            throw new ErrorResponse(
                401,
                'Acesso não autorizado',
                ['message' => 'Não foi possível identificar os dados do token.']
            );
        }

        $request = $request->withAttribute('jwtPayload', $payload);

        return $handler->handle($request);
    }
}
