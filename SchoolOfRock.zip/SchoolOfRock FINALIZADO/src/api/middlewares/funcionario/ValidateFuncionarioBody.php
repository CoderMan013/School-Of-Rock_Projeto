<?php

namespace Api\Middlewares\Funcionario;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use stdClass;

/**
 * Valida os dados enviados no cadastro e na atualização de funcionários.
 */
class ValidateFuncionarioBody implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um corpo JSON válido na requisição.']
            );
        }

        if (!($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O corpo da requisição deve ser um objeto JSON.']
            );
        }

        if (
            !isset($objPHP->funcionario)
            || !($objPHP->funcionario instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "funcionario" é obrigatório e deve ser um objeto.']
            );
        }

        $funcionario = $objPHP->funcionario;

        if (
            !isset($funcionario->nomeFuncionario)
            || !is_string($funcionario->nomeFuncionario)
            || trim($funcionario->nomeFuncionario) === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "nomeFuncionario" é obrigatório.']
            );
        }

        if (
            !isset($funcionario->email)
            || !is_string($funcionario->email)
            || trim($funcionario->email) === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "email" é obrigatório.']
            );
        }

        if (
            !isset($funcionario->cargo)
            || !($funcionario->cargo instanceof stdClass)
            || !isset($funcionario->cargo->idCargo)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "cargo" com "idCargo" é obrigatório.']
            );
        }

        return $handler->handle($request);
    }
}
