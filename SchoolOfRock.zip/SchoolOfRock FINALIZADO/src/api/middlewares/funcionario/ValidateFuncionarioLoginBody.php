<?php

namespace Api\Middlewares\Funcionario;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use stdClass;

/**
 * Valida os dados enviados na requisição de login.
 */
class ValidateFuncionarioLoginBody implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um corpo JSON válido na requisição.']
            );
        }

        if (!($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O corpo da requisição deve ser um objeto JSON.']
            );
        }

        if (
            !isset($objPHP->funcionario)
            || !($objPHP->funcionario instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "funcionario" é obrigatório e deve ser um objeto.']
            );
        }

        $funcionario = $objPHP->funcionario;

        if (!isset($funcionario->email) || !is_string($funcionario->email)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "email" é obrigatório e deve ser um texto.']
            );
        }

        $email = trim($funcionario->email);

        if (
            mb_strlen($email, 'UTF-8') > 64
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Informe um e-mail válido com no máximo 64 caracteres.']
            );
        }

        if (
            !isset($funcionario->senha)
            || !is_string($funcionario->senha)
            || $funcionario->senha === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "senha" é obrigatório e deve ser um texto preenchido.']
            );
        }

        return $handler->handle($request);
    }
}
