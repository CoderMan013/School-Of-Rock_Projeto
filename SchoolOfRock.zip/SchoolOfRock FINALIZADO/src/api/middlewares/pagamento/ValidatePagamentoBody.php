<?php

namespace Api\Middlewares\Pagamento;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use stdClass;

class ValidatePagamentoBody implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um corpo JSON válido na requisição.']
            );
        }

        if (!($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O corpo da requisição deve ser um objeto JSON.']
            );
        }

        if (
            !isset($objPHP->pagamento)
            || !($objPHP->pagamento instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "pagamento" é obrigatório e deve ser um objeto.']
            );
        }

        $pagamento = $objPHP->pagamento;

        if (
            !isset($pagamento->cobranca)
            || !($pagamento->cobranca instanceof stdClass)
            || !isset($pagamento->cobranca->idCobranca)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "cobranca" com "idCobranca" é obrigatório.']
            );
        }

        return $handler->handle($request);
    }
}
