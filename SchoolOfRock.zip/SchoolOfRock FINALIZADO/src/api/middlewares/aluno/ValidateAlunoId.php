<?php

namespace Api\Middlewares\Aluno;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Slim\Routing\RouteContext;
use Api\Http\ErrorResponse;

class ValidateAlunoId implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $routeContext = RouteContext::fromRequest($request);
        $route = $routeContext->getRoute();

        if ($route === null) {
            throw new ErrorResponse(
                404,
                'Rota não encontrada',
                ['message' => 'Não foi possível identificar a rota solicitada.']
            );
        }

        $idAluno = $route->getArgument('idAluno');

        if ($idAluno === null || $idAluno === '') {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O parâmetro "idAluno" é obrigatório.']
            );
        }

        $idValidado = filter_var(
            $idAluno,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($idValidado === false) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O parâmetro "idAluno" deve ser um número inteiro maior que zero.']
            );
        }

        return $handler->handle($request);
    }
}
