<?php

namespace Api\Middlewares\Aluno;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Server\MiddlewareInterface;
use Api\Http\ErrorResponse;
use stdClass;

class ValidateAlunoBody implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um corpo JSON válido na requisição.']
            );
        }

        if (!($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O corpo da requisição deve ser um objeto JSON.']
            );
        }

        if (
            !isset($objPHP->aluno)
            || !($objPHP->aluno instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "aluno" é obrigatório e deve ser um objeto.']
            );
        }

        $aluno = $objPHP->aluno;

        if (
            !isset($aluno->nomeAluno)
            || !is_string($aluno->nomeAluno)
            || trim($aluno->nomeAluno) === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "nomeAluno" é obrigatório.']
            );
        }

        if (
            !isset($aluno->funcionario)
            || !($aluno->funcionario instanceof stdClass)
            || !isset($aluno->funcionario->idFuncionario)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "funcionario" com "idFuncionario" é obrigatório.']
            );
        }

        return $handler->handle($request);
    }
}
