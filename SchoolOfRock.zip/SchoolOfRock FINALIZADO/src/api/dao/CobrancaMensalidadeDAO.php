<?php

namespace Api\DAO;

use Api\Database\MysqlDatabase;
use Api\Models\CobrancaMensalidade;
use Api\Models\Aluno;
use InvalidArgumentException;
use PDO;

/**
 * Acesso aos dados da tabela cobrancamensalidade.
 */
class CobrancaMensalidadeDAO
{
    private MysqlDatabase $database;

    public function __construct(MysqlDatabase $database)
    {
        $this->database = $database;
    }

    public function create(CobrancaMensalidade $cobranca): CobrancaMensalidade
    {
        $sql = "
            INSERT INTO cobrancamensalidade (
                valor,
                vencimento,
                statusCobranca,
                Aluno_idAluno
            )
            VALUES (
                :valor,
                :vencimento,
                :statusCobranca,
                :idAluno
            )
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':valor' => $cobranca->getValor(),
            ':vencimento' => $cobranca->getVencimento(),
            ':statusCobranca' => $cobranca->getStatusCobranca(),
            ':idAluno' => $cobranca->getAluno()->getIdAluno()
        ]);

        $cobranca->setIdCobranca((int) $pdo->lastInsertId());

        return $cobranca;
    }

    public function update(CobrancaMensalidade $cobranca): bool
    {
        $sql = "
            UPDATE cobrancamensalidade
            SET
                valor = :valor,
                vencimento = :vencimento,
                statusCobranca = :statusCobranca,
                Aluno_idAluno = :idAluno
            WHERE idCobranca = :id
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':valor' => $cobranca->getValor(),
            ':vencimento' => $cobranca->getVencimento(),
            ':statusCobranca' => $cobranca->getStatusCobranca(),
            ':idAluno' => $cobranca->getAluno()->getIdAluno(),
            ':id' => $cobranca->getIdCobranca()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function delete(CobrancaMensalidade $cobranca): bool
    {
        $sql = "DELETE FROM cobrancamensalidade WHERE idCobranca = :id";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':id' => $cobranca->getIdCobranca()]);

        return $stmt->rowCount() > 0;
    }

    public function findAll(): array
    {
        $sql = "SELECT * FROM cobrancamensalidade ORDER BY idCobranca";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $cobrancas = [];

        foreach ($linhas as $linha) {
            $cobrancas[] = $this->montarCobranca($linha);
        }

        return $cobrancas;
    }

    public function count(): int
    {
        $sql = "SELECT COUNT(*) FROM cobrancamensalidade";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        return (int) $stmt->fetchColumn();
    }

    public function findById(int $idCobranca): ?CobrancaMensalidade
    {
        $cobrancas = $this->findByField('idCobranca', $idCobranca);

        return $cobrancas[0] ?? null;
    }

    public function findByField(string $field, $value): array
    {
        $camposPermitidos = [
            'idCobranca',
            'statusCobranca',
            'Aluno_idAluno'
        ];

        if (!in_array($field, $camposPermitidos, true)) {
            throw new InvalidArgumentException(
                'Campo de consulta inválido para cobranças.'
            );
        }

        $sql = "SELECT * FROM cobrancamensalidade WHERE `$field` = :value ORDER BY idCobranca";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':value' => $value]);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $cobrancas = [];

        foreach ($linhas as $linha) {
            $cobrancas[] = $this->montarCobranca($linha);
        }

        return $cobrancas;
    }

    private function montarCobranca(array $linha): CobrancaMensalidade
    {
        $aluno = new Aluno();
        $aluno->setIdAluno((int) $linha['Aluno_idAluno']);

        $cobranca = new CobrancaMensalidade();

        $cobranca->setIdCobranca((int) $linha['idCobranca']);
        $cobranca->setValor((float) $linha['valor']);
        $cobranca->setVencimento($linha['vencimento']);
        $cobranca->setStatusCobranca($linha['statusCobranca']);
        $cobranca->setAluno($aluno);

        return $cobranca;
    }
}
