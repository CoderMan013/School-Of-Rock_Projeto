<?php

namespace Api\DAO;

use Api\Database\MysqlDatabase;
use Api\Models\Aluno;
use Api\Models\Funcionario;
use InvalidArgumentException;
use PDO;

/**
 * Acesso aos dados da tabela aluno.
 */
class AlunoDAO
{
    private MysqlDatabase $database;

    public function __construct(MysqlDatabase $database)
    {
        $this->database = $database;
    }

    public function create(Aluno $aluno): Aluno
    {
        $sql = "
            INSERT INTO aluno (
                nomeAluno,
                telefone,
                email,
                instrumento,
                Funcionario_idFuncionario
            )
            VALUES (
                :nomeAluno,
                :telefone,
                :email,
                :instrumento,
                :idFuncionario
            )
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':nomeAluno' => $aluno->getNomeAluno(),
            ':telefone' => $aluno->getTelefone(),
            ':email' => $aluno->getEmail(),
            ':instrumento' => $aluno->getInstrumento(),
            ':idFuncionario' => $aluno->getFuncionario()->getIdFuncionario()
        ]);

        $aluno->setIdAluno((int) $pdo->lastInsertId());

        return $aluno;
    }

    public function update(Aluno $aluno): bool
    {
        $sql = "
            UPDATE aluno
            SET
                nomeAluno = :nomeAluno,
                telefone = :telefone,
                email = :email,
                instrumento = :instrumento,
                Funcionario_idFuncionario = :idFuncionario
            WHERE idAluno = :id
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':nomeAluno' => $aluno->getNomeAluno(),
            ':telefone' => $aluno->getTelefone(),
            ':email' => $aluno->getEmail(),
            ':instrumento' => $aluno->getInstrumento(),
            ':idFuncionario' => $aluno->getFuncionario()->getIdFuncionario(),
            ':id' => $aluno->getIdAluno()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function delete(Aluno $aluno): bool
    {
        $sql = "DELETE FROM aluno WHERE idAluno = :id";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':id' => $aluno->getIdAluno()]);

        return $stmt->rowCount() > 0;
    }

    public function findAll(): array
    {
        $sql = "SELECT * FROM aluno ORDER BY idAluno";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $alunos = [];

        foreach ($linhas as $linha) {
            $alunos[] = $this->montarAluno($linha);
        }

        return $alunos;
    }

    public function count(): int
    {
        $sql = "SELECT COUNT(*) FROM aluno";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        return (int) $stmt->fetchColumn();
    }

    public function findById(int $idAluno): ?Aluno
    {
        $alunos = $this->findByField('idAluno', $idAluno);

        return $alunos[0] ?? null;
    }

    public function findByField(string $field, $value): array
    {
        $camposPermitidos = [
            'idAluno',
            'nomeAluno',
            'email',
            'instrumento',
            'Funcionario_idFuncionario'
        ];

        if (!in_array($field, $camposPermitidos, true)) {
            throw new InvalidArgumentException(
                'Campo de consulta inválido para alunos.'
            );
        }

        $condicao = $value === null
            ? "`{$field}` IS NULL"
            : "`{$field}` = :value";

        $sql = "SELECT * FROM aluno WHERE {$condicao} ORDER BY idAluno";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $parametros = $value === null ? [] : [':value' => $value];

        $stmt->execute($parametros);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $alunos = [];

        foreach ($linhas as $linha) {
            $alunos[] = $this->montarAluno($linha);
        }

        return $alunos;
    }

    private function montarAluno(array $linha): Aluno
    {
        $funcionario = new Funcionario();
        $funcionario->setIdFuncionario((int) $linha['Funcionario_idFuncionario']);

        $aluno = new Aluno();

        $aluno->setIdAluno((int) $linha['idAluno']);
        $aluno->setNomeAluno($linha['nomeAluno']);
        $aluno->setTelefone($linha['telefone']);
        $aluno->setEmail($linha['email']);
        $aluno->setInstrumento($linha['instrumento']);
        $aluno->setFuncionario($funcionario);

        return $aluno;
    }
}
