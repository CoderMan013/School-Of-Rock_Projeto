<?php

namespace Api\DAO;

use Api\Database\MysqlDatabase;
use Api\Models\Pagamento;
use Api\Models\CobrancaMensalidade;
use InvalidArgumentException;
use PDO;

/**
 * Acesso aos dados da tabela pagamento.
 */
class PagamentoDAO
{
    private MysqlDatabase $database;

    public function __construct(MysqlDatabase $database)
    {
        $this->database = $database;
    }

    public function create(Pagamento $pagamento): Pagamento
    {
        $sql = "
            INSERT INTO pagamento (
                dataPagamento,
                valorPago,
                formaPagamento,
                Cobranca_idCobranca
            )
            VALUES (
                :dataPagamento,
                :valorPago,
                :formaPagamento,
                :idCobranca
            )
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':dataPagamento' => $pagamento->getDataPagamento(),
            ':valorPago' => $pagamento->getValorPago(),
            ':formaPagamento' => $pagamento->getFormaPagamento(),
            ':idCobranca' => $pagamento->getCobranca()->getIdCobranca()
        ]);

        $pagamento->setIdPagamento((int) $pdo->lastInsertId());

        return $pagamento;
    }

    public function update(Pagamento $pagamento): bool
    {
        $sql = "
            UPDATE pagamento
            SET
                dataPagamento = :dataPagamento,
                valorPago = :valorPago,
                formaPagamento = :formaPagamento,
                Cobranca_idCobranca = :idCobranca
            WHERE idPagamento = :id
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':dataPagamento' => $pagamento->getDataPagamento(),
            ':valorPago' => $pagamento->getValorPago(),
            ':formaPagamento' => $pagamento->getFormaPagamento(),
            ':idCobranca' => $pagamento->getCobranca()->getIdCobranca(),
            ':id' => $pagamento->getIdPagamento()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function delete(Pagamento $pagamento): bool
    {
        $sql = "DELETE FROM pagamento WHERE idPagamento = :id";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':id' => $pagamento->getIdPagamento()]);

        return $stmt->rowCount() > 0;
    }

    public function findAll(): array
    {
        $sql = "SELECT * FROM pagamento ORDER BY idPagamento";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $pagamentos = [];

        foreach ($linhas as $linha) {
            $pagamentos[] = $this->montarPagamento($linha);
        }

        return $pagamentos;
    }

    public function count(): int
    {
        $sql = "SELECT COUNT(*) FROM pagamento";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        return (int) $stmt->fetchColumn();
    }

    public function findById(int $idPagamento): ?Pagamento
    {
        $pagamentos = $this->findByField('idPagamento', $idPagamento);

        return $pagamentos[0] ?? null;
    }

    public function findByField(string $field, $value): array
    {
        $camposPermitidos = [
            'idPagamento',
            'Cobranca_idCobranca'
        ];

        if (!in_array($field, $camposPermitidos, true)) {
            throw new InvalidArgumentException(
                'Campo de consulta inválido para pagamentos.'
            );
        }

        $sql = "SELECT * FROM pagamento WHERE `$field` = :value ORDER BY idPagamento";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':value' => $value]);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $pagamentos = [];

        foreach ($linhas as $linha) {
            $pagamentos[] = $this->montarPagamento($linha);
        }

        return $pagamentos;
    }

    private function montarPagamento(array $linha): Pagamento
    {
        $cobranca = new CobrancaMensalidade();
        $cobranca->setIdCobranca((int) $linha['Cobranca_idCobranca']);

        $pagamento = new Pagamento();

        $pagamento->setIdPagamento((int) $linha['idPagamento']);
        $pagamento->setDataPagamento($linha['dataPagamento']);
        $pagamento->setValorPago(
            $linha['valorPago'] === null ? null : (float) $linha['valorPago']
        );
        $pagamento->setFormaPagamento($linha['formaPagamento']);
        $pagamento->setCobranca($cobranca);

        return $pagamento;
    }
}
