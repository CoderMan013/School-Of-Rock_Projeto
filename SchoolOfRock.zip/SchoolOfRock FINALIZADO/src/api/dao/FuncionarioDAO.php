<?php

namespace Api\DAO;

use Api\Database\MysqlDatabase;
use Api\Models\Funcionario;
use Api\Models\Cargo;
use InvalidArgumentException;
use PDO;

/**
 * Acesso aos dados da tabela funcionario.
 *
 * Também é utilizada no login, através de findByEmail().
 */
class FuncionarioDAO
{
    private MysqlDatabase $database;

    public function __construct(MysqlDatabase $database)
    {
        $this->database = $database;
    }

    public function create(Funcionario $funcionario): Funcionario
    {
        $sql = "
            INSERT INTO funcionario (
                nomeFuncionario,
                email,
                senha,
                recebeValeTransporte,
                Cargo_idCargo
            )
            VALUES (
                :nomeFuncionario,
                :email,
                :senha,
                :recebeValeTransporte,
                :idCargo
            )
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':nomeFuncionario' => $funcionario->getNomeFuncionario(),
            ':email' => $funcionario->getEmail(),
            ':senha' => $funcionario->getSenhaHash(),
            ':recebeValeTransporte' => $funcionario->getRecebeValeTransporte() ? 1 : 0,
            ':idCargo' => $funcionario->getCargo()->getIdCargo()
        ]);

        $funcionario->setIdFuncionario((int) $pdo->lastInsertId());

        return $funcionario;
    }

    public function update(Funcionario $funcionario): bool
    {
        $sql = "
            UPDATE funcionario
            SET
                nomeFuncionario = :nomeFuncionario,
                email = :email,
                senha = :senha,
                recebeValeTransporte = :recebeValeTransporte,
                Cargo_idCargo = :idCargo
            WHERE idFuncionario = :id
        ";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':nomeFuncionario' => $funcionario->getNomeFuncionario(),
            ':email' => $funcionario->getEmail(),
            ':senha' => $funcionario->getSenhaHash(),
            ':recebeValeTransporte' => $funcionario->getRecebeValeTransporte() ? 1 : 0,
            ':idCargo' => $funcionario->getCargo()->getIdCargo(),
            ':id' => $funcionario->getIdFuncionario()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function delete(Funcionario $funcionario): bool
    {
        $sql = "DELETE FROM funcionario WHERE idFuncionario = :id";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':id' => $funcionario->getIdFuncionario()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function findAll(): array
    {
        $sql = "SELECT * FROM funcionario ORDER BY idFuncionario";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $funcionarios = [];

        foreach ($linhas as $linha) {
            $funcionarios[] = $this->montarFuncionario($linha);
        }

        return $funcionarios;
    }

    public function count(): int
    {
        $sql = "SELECT COUNT(*) FROM funcionario";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->query($sql);

        return (int) $stmt->fetchColumn();
    }

    public function findById(int $idFuncionario): ?Funcionario
    {
        $funcionarios = $this->findByField('idFuncionario', $idFuncionario);

        return $funcionarios[0] ?? null;
    }

    public function findByEmail(string $email): ?Funcionario
    {
        $funcionarios = $this->findByField('email', strtolower(trim($email)));

        return $funcionarios[0] ?? null;
    }

    public function findByField(string $field, $value): array
    {
        $camposPermitidos = [
            'idFuncionario',
            'nomeFuncionario',
            'email',
            'Cargo_idCargo'
        ];

        if (!in_array($field, $camposPermitidos, true)) {
            throw new InvalidArgumentException(
                'Campo de consulta inválido para funcionários.'
            );
        }

        $sql = "SELECT * FROM funcionario WHERE `$field` = :value ORDER BY idFuncionario";

        $pdo = $this->database->getConnection();
        $stmt = $pdo->prepare($sql);

        $stmt->execute([':value' => $value]);

        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $funcionarios = [];

        foreach ($linhas as $linha) {
            $funcionarios[] = $this->montarFuncionario($linha);
        }

        return $funcionarios;
    }

    private function montarFuncionario(array $linha): Funcionario
    {
        $cargo = new Cargo();
        $cargo->setIdCargo((int) $linha['Cargo_idCargo']);

        $funcionario = new Funcionario();

        $funcionario->setIdFuncionario((int) $linha['idFuncionario']);
        $funcionario->setNomeFuncionario($linha['nomeFuncionario'] ?? '');
        $funcionario->setEmail($linha['email']);
        $funcionario->setSenhaHash($linha['senha']);
        $funcionario->setRecebeValeTransporte((bool) $linha['recebeValeTransporte']);
        $funcionario->setCargo($cargo);

        return $funcionario;
    }
}
