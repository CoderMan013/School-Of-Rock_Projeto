<?php

namespace Api\DAO;

use Api\Models\Cargo;
use Api\Database\MysqlDatabase;
use Exception;

/**
 * Acesso aos dados da tabela cargo.
 */
class CargoDAO
{
    private MysqlDatabase $database;

    public function __construct(MysqlDatabase $databaseInstance)
    {
        $this->database = $databaseInstance;
    }

    public function create(Cargo $objCargo): Cargo
    {
        $sql = "INSERT INTO cargo (nomeCargo) VALUES (:nome)";

        $stmt = $this->database->getConnection()->prepare($sql);

        $stmt->execute([
            ':nome' => $objCargo->getNomeCargo()
        ]);

        $novoID = (int) $this->database->getConnection()->lastInsertId();
        $objCargo->setIdCargo($novoID);

        return $objCargo;
    }

    public function delete(Cargo $objCargo): bool
    {
        $sql = "DELETE FROM cargo WHERE idCargo = :idCargo";

        $stmt = $this->database->getConnection()->prepare($sql);

        $stmt->execute([
            ':idCargo' => $objCargo->getIdCargo()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function update(Cargo $objCargo): bool
    {
        $sql = "UPDATE cargo SET nomeCargo = :nome WHERE idCargo = :id";

        $stmt = $this->database->getConnection()->prepare($sql);

        $stmt->execute([
            ':nome' => $objCargo->getNomeCargo(),
            ':id' => $objCargo->getIdCargo()
        ]);

        return $stmt->rowCount() > 0;
    }

    public function findAll(): array
    {
        $sql = "SELECT * FROM cargo ORDER BY idCargo";

        $stmt = $this->database->getConnection()->query($sql);

        $matriz = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $cargos = [];

        foreach ($matriz as $linha) {
            $cargos[] = $this->montarCargo($linha);
        }

        return $cargos;
    }

    public function count(): int
    {
        $sql = "SELECT COUNT(*) AS qtd FROM cargo";

        $stmt = $this->database->getConnection()->query($sql);

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return (int) $row['qtd'];
    }

    public function findById(int $idCargo): ?Cargo
    {
        $resultado = $this->findByField('idCargo', $idCargo);

        return $resultado[0] ?? null;
    }

    public function findByField(string $field, $value): array
    {
        $camposPermitidos = ['idCargo', 'nomeCargo'];

        if (!in_array($field, $camposPermitidos)) {
            throw new Exception("Campo inválido.");
        }

        $sql = "SELECT * FROM cargo WHERE `$field` = :value ORDER BY idCargo";

        $stmt = $this->database->getConnection()->prepare($sql);

        $stmt->execute([
            ':value' => $value
        ]);

        $matriz = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $cargos = [];

        foreach ($matriz as $linha) {
            $cargos[] = $this->montarCargo($linha);
        }

        return $cargos;
    }

    private function montarCargo(array $linha): Cargo
    {
        $cargo = new Cargo();

        $cargo->setIdCargo((int) $linha['idCargo']);
        $cargo->setNomeCargo($linha['nomeCargo']);

        return $cargo;
    }
}
