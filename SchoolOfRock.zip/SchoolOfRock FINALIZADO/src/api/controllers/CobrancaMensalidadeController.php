<?php

namespace Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Api\services\CobrancaMensalidadeService;
use Api\Http\ErrorResponse;
use stdClass;

class CobrancaMensalidadeController
{
    private CobrancaMensalidadeService $cobrancaService;

    public function __construct(CobrancaMensalidadeService $cobrancaService)
    {
        $this->cobrancaService = $cobrancaService;
    }

    public function createController(Request $request, Response $response, array $args): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE || !($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um objeto JSON válido no corpo da requisição.']
            );
        }

        $novaCobranca = $this->cobrancaService->createService($objPHP);

        $resposta = [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso',
            'data' => ['cobrancas' => [$novaCobranca]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(201);
    }

    public function findAllController(Request $request, Response $response, array $args): Response
    {
        $cobrancas = $this->cobrancaService->findAllService();

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['cobrancas' => $cobrancas]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function findByIdController(Request $request, Response $response, array $args): Response
    {
        $idCobranca = (int) $args['idCobranca'];

        $cobranca = $this->cobrancaService->findByIdService($idCobranca);

        if ($cobranca === null) {
            throw new ErrorResponse(
                404,
                'Cobrança não encontrada',
                ['message' => "Não existe cobrança com id {$idCobranca}."]
            );
        }

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['cobrancas' => $cobranca]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function updateController(Request $request, Response $response, array $args): Response
    {
        $idCobranca = (int) $args['idCobranca'];

        $body = (string) $request->getBody();
        $arrayPHP = json_decode($body, true);

        if (
            json_last_error() !== JSON_ERROR_NONE
            || !is_array($arrayPHP)
            || !isset($arrayPHP['cobranca'])
            || !is_array($arrayPHP['cobranca'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Envie um objeto JSON contendo os dados de "cobranca".']
            );
        }

        $cobrancaAtualizada = $this->cobrancaService->updateService($idCobranca, $arrayPHP);

        $resposta = [
            'success' => true,
            'message' => 'Atualizado com sucesso',
            'data' => ['cobrancas' => [$cobrancaAtualizada]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function deleteController(Request $request, Response $response, array $args): Response
    {
        $idCobranca = (int) $args['idCobranca'];

        $this->cobrancaService->deleteService($idCobranca);

        $resposta = [
            'success' => true,
            'message' => 'Excluído com sucesso',
            'data' => ['cobrancas' => [['idCobranca' => $idCobranca]]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function countController(Request $request, Response $response, array $args): Response
    {
        $total = $this->cobrancaService->countService();

        $resposta = [
            'success' => true,
            'message' => 'Contagem realizada com sucesso',
            'data' => ['count' => $total]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }
}
