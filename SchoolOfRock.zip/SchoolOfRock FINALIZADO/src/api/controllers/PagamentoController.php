<?php

namespace Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Api\services\PagamentoService;
use Api\Http\ErrorResponse;
use stdClass;

class PagamentoController
{
    private PagamentoService $pagamentoService;

    public function __construct(PagamentoService $pagamentoService)
    {
        $this->pagamentoService = $pagamentoService;
    }

    public function createController(Request $request, Response $response, array $args): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE || !($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um objeto JSON válido no corpo da requisição.']
            );
        }

        $novoPagamento = $this->pagamentoService->createService($objPHP);

        $resposta = [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso',
            'data' => ['pagamentos' => [$novoPagamento]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(201);
    }

    public function findAllController(Request $request, Response $response, array $args): Response
    {
        $pagamentos = $this->pagamentoService->findAllService();

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['pagamentos' => $pagamentos]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function findByIdController(Request $request, Response $response, array $args): Response
    {
        $idPagamento = (int) $args['idPagamento'];

        $pagamento = $this->pagamentoService->findByIdService($idPagamento);

        if ($pagamento === null) {
            throw new ErrorResponse(
                404,
                'Pagamento não encontrado',
                ['message' => "Não existe pagamento com id {$idPagamento}."]
            );
        }

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['pagamentos' => $pagamento]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function updateController(Request $request, Response $response, array $args): Response
    {
        $idPagamento = (int) $args['idPagamento'];

        $body = (string) $request->getBody();
        $arrayPHP = json_decode($body, true);

        if (
            json_last_error() !== JSON_ERROR_NONE
            || !is_array($arrayPHP)
            || !isset($arrayPHP['pagamento'])
            || !is_array($arrayPHP['pagamento'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Envie um objeto JSON contendo os dados de "pagamento".']
            );
        }

        $pagamentoAtualizado = $this->pagamentoService->updateService($idPagamento, $arrayPHP);

        $resposta = [
            'success' => true,
            'message' => 'Atualizado com sucesso',
            'data' => ['pagamentos' => [$pagamentoAtualizado]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function deleteController(Request $request, Response $response, array $args): Response
    {
        $idPagamento = (int) $args['idPagamento'];

        $this->pagamentoService->deleteService($idPagamento);

        $resposta = [
            'success' => true,
            'message' => 'Excluído com sucesso',
            'data' => ['pagamentos' => [['idPagamento' => $idPagamento]]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function countController(Request $request, Response $response, array $args): Response
    {
        $total = $this->pagamentoService->countService();

        $resposta = [
            'success' => true,
            'message' => 'Contagem realizada com sucesso',
            'data' => ['count' => $total]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }
}
