<?php

namespace Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Api\services\CargoService;
use Api\Http\ErrorResponse;
use stdClass;

class CargoController
{
    private CargoService $cargoService;

    public function __construct(CargoService $cargoService)
    {
        $this->cargoService = $cargoService;
    }

    public function createController(Request $request, Response $response, array $args): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE || !($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um objeto JSON válido no corpo da requisição.']
            );
        }

        $novoCargo = $this->cargoService->createService($objPHP);

        $resposta = [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso',
            'data' => ['cargos' => [$novoCargo]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(201);
    }

    public function findAllController(Request $request, Response $response, array $args): Response
    {
        $cargos = $this->cargoService->findAllService();

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['cargos' => $cargos]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function findByIdController(Request $request, Response $response, array $args): Response
    {
        $idCargo = (int) $args['idCargo'];

        $cargo = $this->cargoService->findByIdService($idCargo);

        if ($cargo === null) {
            throw new ErrorResponse(
                404,
                'Cargo não encontrado',
                ['message' => "Não existe cargo com id {$idCargo}."]
            );
        }

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['cargos' => $cargo]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function updateController(Request $request, Response $response, array $args): Response
    {
        $idCargo = (int) $args['idCargo'];

        $body = (string) $request->getBody();
        $arrayPHP = json_decode($body, true);

        if (
            json_last_error() !== JSON_ERROR_NONE
            || !is_array($arrayPHP)
            || !isset($arrayPHP['cargo'])
            || !is_array($arrayPHP['cargo'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Envie um objeto JSON contendo os dados de "cargo".']
            );
        }

        $cargoAtualizado = $this->cargoService->updateService($idCargo, $arrayPHP);

        $resposta = [
            'success' => true,
            'message' => 'Atualizado com sucesso',
            'data' => ['cargos' => [$cargoAtualizado]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function deleteController(Request $request, Response $response, array $args): Response
    {
        $idCargo = (int) $args['idCargo'];

        $this->cargoService->deleteService($idCargo);

        $resposta = [
            'success' => true,
            'message' => 'Excluído com sucesso',
            'data' => ['cargos' => [['idCargo' => $idCargo]]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function countController(Request $request, Response $response, array $args): Response
    {
        $total = $this->cargoService->countService();

        $resposta = [
            'success' => true,
            'message' => 'Contagem realizada com sucesso',
            'data' => ['count' => $total]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }
}
