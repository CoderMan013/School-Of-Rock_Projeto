<?php

namespace Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Api\services\FuncionarioService;
use Api\Http\ErrorResponse;
use stdClass;

class FuncionarioController
{
    private FuncionarioService $funcionarioService;

    public function __construct(FuncionarioService $funcionarioService)
    {
        $this->funcionarioService = $funcionarioService;
    }

    public function createController(Request $request, Response $response, array $args): Response
    {
        $objPHP = $this->lerObjeto($request);

        $novoFuncionario = $this->funcionarioService->createService($objPHP);

        $resposta = [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso',
            'data' => ['funcionarios' => [$novoFuncionario]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(201);
    }

    public function findAllController(Request $request, Response $response, array $args): Response
    {
        $funcionarios = $this->funcionarioService->findAllService();

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['funcionarios' => $funcionarios]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function findByIdController(Request $request, Response $response, array $args): Response
    {
        $idFuncionario = (int) $args['idFuncionario'];

        $funcionario = $this->funcionarioService->findByIdService($idFuncionario);

        if ($funcionario === null) {
            throw new ErrorResponse(
                404,
                'Funcionário não encontrado',
                ['message' => "Não existe funcionário com id {$idFuncionario}."]
            );
        }

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['funcionarios' => $funcionario]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function updateController(Request $request, Response $response, array $args): Response
    {
        $idFuncionario = (int) $args['idFuncionario'];

        $body = (string) $request->getBody();
        $arrayPHP = json_decode($body, true);

        if (
            json_last_error() !== JSON_ERROR_NONE
            || !is_array($arrayPHP)
            || !isset($arrayPHP['funcionario'])
            || !is_array($arrayPHP['funcionario'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Envie um objeto JSON contendo os dados de "funcionario".']
            );
        }

        $funcionarioAtualizado = $this->funcionarioService->updateService($idFuncionario, $arrayPHP);

        $resposta = [
            'success' => true,
            'message' => 'Atualizado com sucesso',
            'data' => ['funcionarios' => [$funcionarioAtualizado]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function deleteController(Request $request, Response $response, array $args): Response
    {
        $idFuncionario = (int) $args['idFuncionario'];

        $this->funcionarioService->deleteService($idFuncionario);

        $resposta = [
            'success' => true,
            'message' => 'Excluído com sucesso',
            'data' => ['funcionarios' => [['idFuncionario' => $idFuncionario]]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function countController(Request $request, Response $response, array $args): Response
    {
        $total = $this->funcionarioService->countService();

        $resposta = [
            'success' => true,
            'message' => 'Contagem realizada com sucesso',
            'data' => ['count' => $total]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    /**
     * POST /login
     * Autentica o funcionário e retorna o JWT.
     */
    public function loginController(Request $request, Response $response, array $args): Response
    {
        $objPHP = $this->lerObjeto($request);

        if (
            !isset($objPHP->funcionario)
            || !($objPHP->funcionario instanceof stdClass)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "funcionario" é obrigatório e deve ser um objeto.']
            );
        }

        $resultado = $this->funcionarioService->loginService(
            (array) $objPHP->funcionario
        );

        $resposta = [
            'success' => true,
            'message' => 'Login realizado com sucesso',
            'data' => [
                'funcionario' => $resultado['funcionario'],
                'token' => $resultado['token']
            ]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withHeader('Cache-Control', 'no-store')
            ->withStatus(200);
    }

    private function lerObjeto(Request $request): stdClass
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE || !($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um objeto JSON válido no corpo da requisição.']
            );
        }

        return $objPHP;
    }
}
