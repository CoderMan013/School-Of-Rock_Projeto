<?php

namespace Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Api\services\AlunoService;
use Api\Http\ErrorResponse;
use stdClass;

class AlunoController
{
    private AlunoService $alunoService;

    public function __construct(AlunoService $alunoService)
    {
        $this->alunoService = $alunoService;
    }

    public function createController(Request $request, Response $response, array $args): Response
    {
        $body = (string) $request->getBody();
        $objPHP = json_decode($body);

        if (json_last_error() !== JSON_ERROR_NONE || !($objPHP instanceof stdClass)) {
            throw new ErrorResponse(
                400,
                'JSON inválido',
                ['message' => 'Envie um objeto JSON válido no corpo da requisição.']
            );
        }

        $novoAluno = $this->alunoService->createService($objPHP);

        $resposta = [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso',
            'data' => ['alunos' => [$novoAluno]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(201);
    }

    public function findAllController(Request $request, Response $response, array $args): Response
    {
        $alunos = $this->alunoService->findAllService();

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['alunos' => $alunos]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function findByIdController(Request $request, Response $response, array $args): Response
    {
        $idAluno = (int) $args['idAluno'];

        $aluno = $this->alunoService->findByIdService($idAluno);

        if ($aluno === null) {
            throw new ErrorResponse(
                404,
                'Aluno não encontrado',
                ['message' => "Não existe aluno com id {$idAluno}."]
            );
        }

        $resposta = [
            'success' => true,
            'message' => 'Busca realizada com sucesso',
            'data' => ['alunos' => $aluno]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function updateController(Request $request, Response $response, array $args): Response
    {
        $idAluno = (int) $args['idAluno'];

        $body = (string) $request->getBody();
        $arrayPHP = json_decode($body, true);

        if (
            json_last_error() !== JSON_ERROR_NONE
            || !is_array($arrayPHP)
            || !isset($arrayPHP['aluno'])
            || !is_array($arrayPHP['aluno'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Envie um objeto JSON contendo os dados de "aluno".']
            );
        }

        $alunoAtualizado = $this->alunoService->updateService($idAluno, $arrayPHP);

        $resposta = [
            'success' => true,
            'message' => 'Atualizado com sucesso',
            'data' => ['alunos' => [$alunoAtualizado]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function deleteController(Request $request, Response $response, array $args): Response
    {
        $idAluno = (int) $args['idAluno'];

        $this->alunoService->deleteService($idAluno);

        $resposta = [
            'success' => true,
            'message' => 'Excluído com sucesso',
            'data' => ['alunos' => [['idAluno' => $idAluno]]]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }

    public function countController(Request $request, Response $response, array $args): Response
    {
        $total = $this->alunoService->countService();

        $resposta = [
            'success' => true,
            'message' => 'Contagem realizada com sucesso',
            'data' => ['count' => $total]
        ];

        $response->getBody()->write(json_encode($resposta, JSON_UNESCAPED_UNICODE));

        return $response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus(200);
    }
}
