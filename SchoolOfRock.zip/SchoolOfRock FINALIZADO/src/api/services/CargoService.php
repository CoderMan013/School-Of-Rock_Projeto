<?php

namespace Api\services;

use Api\Models\Cargo;
use Api\DAO\CargoDAO;
use Api\DAO\FuncionarioDAO;
use Api\Http\ErrorResponse;
use InvalidArgumentException;
use stdClass;

/**
 * Regras de negócio dos cargos.
 */
class CargoService
{
    private CargoDAO $cargoDAO;
    private FuncionarioDAO $funcionarioDAO;

    public function __construct(
        CargoDAO $cargoDAO,
        FuncionarioDAO $funcionarioDAO
    ) {
        $this->cargoDAO = $cargoDAO;
        $this->funcionarioDAO = $funcionarioDAO;
    }

    public function createService(stdClass $objPHP): Cargo
    {
        if (
            !isset($objPHP->cargo)
            || !($objPHP->cargo instanceof stdClass)
        ) {
            throw new InvalidArgumentException(
                'O campo "cargo" é obrigatório e deve ser um objeto.'
            );
        }

        $cargo = $this->montarCargo((array) $objPHP->cargo);

        $this->verificarNomeDuplicado($cargo->getNomeCargo());

        return $this->cargoDAO->create($cargo);
    }

    public function countService(): int
    {
        return $this->cargoDAO->count();
    }

    public function findAllService(): array
    {
        return $this->cargoDAO->findAll();
    }

    public function findByIdService(int $idCargo): ?Cargo
    {
        return $this->cargoDAO->findById($idCargo);
    }

    public function updateService(int $idCargo, array $requestBody): Cargo
    {
        $cargoExistente = $this->cargoDAO->findById($idCargo);

        if ($cargoExistente === null) {
            throw new ErrorResponse(
                404,
                'Cargo não encontrado',
                ['message' => "Não existe cargo com id {$idCargo}."]
            );
        }

        if (
            !isset($requestBody['cargo'])
            || !is_array($requestBody['cargo'])
        ) {
            throw new InvalidArgumentException(
                'O campo "cargo" é obrigatório e deve conter os dados do cargo.'
            );
        }

        $cargo = $this->montarCargo($requestBody['cargo']);
        $cargo->setIdCargo($idCargo);

        $this->verificarNomeDuplicado($cargo->getNomeCargo(), $idCargo);

        $this->cargoDAO->update($cargo);

        return $cargo;
    }

    public function deleteService(int $idCargo): bool
    {
        $cargoExistente = $this->cargoDAO->findById($idCargo);

        if ($cargoExistente === null) {
            throw new ErrorResponse(
                404,
                'Cargo não encontrado',
                ['message' => "Não existe cargo com id {$idCargo}."]
            );
        }

        $funcionariosVinculados = $this->funcionarioDAO->findByField(
            'Cargo_idCargo',
            $idCargo
        );

        if (count($funcionariosVinculados) > 0) {
            throw new ErrorResponse(
                409,
                'Não foi possível excluir o cargo',
                [
                    'message' => 'Existem funcionários vinculados a esse cargo. '
                        . 'Resolva esses vínculos antes de excluí-lo.'
                ]
            );
        }

        return $this->cargoDAO->delete($cargoExistente);
    }

    private function montarCargo(array $dadosCargo): Cargo
    {
        if (
            !isset($dadosCargo['nomeCargo'])
            || !is_string($dadosCargo['nomeCargo'])
        ) {
            throw new InvalidArgumentException(
                'O campo "nomeCargo" é obrigatório e deve ser um texto.'
            );
        }

        $cargo = new Cargo();
        $cargo->setNomeCargo($dadosCargo['nomeCargo']);

        return $cargo;
    }

    private function verificarNomeDuplicado(
        string $nomeCargo,
        ?int $idIgnorado = null
    ): void {
        $cargosEncontrados = $this->cargoDAO->findByField('nomeCargo', $nomeCargo);

        foreach ($cargosEncontrados as $outroCargo) {
            if ($outroCargo->getIdCargo() !== $idIgnorado) {
                throw new ErrorResponse(
                    409,
                    'Cargo já cadastrado',
                    ['message' => 'Outro cargo já utiliza esse nome.']
                );
            }
        }
    }
}
