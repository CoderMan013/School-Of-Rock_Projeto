<?php

namespace Api\services;

use Api\Models\Aluno;
use Api\DAO\AlunoDAO;
use Api\DAO\FuncionarioDAO;
use Api\DAO\CobrancaMensalidadeDAO;
use Api\Http\ErrorResponse;
use InvalidArgumentException;
use stdClass;

/**
 * Regras de negócio dos alunos.
 */
class AlunoService
{
    private AlunoDAO $alunoDAO;
    private FuncionarioDAO $funcionarioDAO;
    private CobrancaMensalidadeDAO $cobrancaDAO;

    public function __construct(
        AlunoDAO $alunoDAO,
        FuncionarioDAO $funcionarioDAO,
        CobrancaMensalidadeDAO $cobrancaDAO
    ) {
        $this->alunoDAO = $alunoDAO;
        $this->funcionarioDAO = $funcionarioDAO;
        $this->cobrancaDAO = $cobrancaDAO;
    }

    public function createService(stdClass $objPHP): Aluno
    {
        if (
            !isset($objPHP->aluno)
            || !($objPHP->aluno instanceof stdClass)
        ) {
            throw new InvalidArgumentException(
                'O campo "aluno" é obrigatório e deve ser um objeto.'
            );
        }

        $aluno = $this->montarAluno((array) $objPHP->aluno);

        $this->verificarEmailDuplicado($aluno->getEmail());

        return $this->alunoDAO->create($aluno);
    }

    public function countService(): int
    {
        return $this->alunoDAO->count();
    }

    public function findAllService(): array
    {
        return $this->alunoDAO->findAll();
    }

    public function findByIdService(int $idAluno): ?Aluno
    {
        return $this->alunoDAO->findById($idAluno);
    }

    public function updateService(int $idAluno, array $requestBody): Aluno
    {
        $alunoExistente = $this->alunoDAO->findById($idAluno);

        if ($alunoExistente === null) {
            throw new ErrorResponse(
                404,
                'Aluno não encontrado',
                ['message' => "Não existe aluno com id {$idAluno}."]
            );
        }

        if (
            !isset($requestBody['aluno'])
            || !is_array($requestBody['aluno'])
        ) {
            throw new InvalidArgumentException(
                'O campo "aluno" é obrigatório e deve conter os dados do aluno.'
            );
        }

        $aluno = $this->montarAluno($requestBody['aluno']);
        $aluno->setIdAluno($idAluno);

        $this->verificarEmailDuplicado($aluno->getEmail(), $idAluno);

        $this->alunoDAO->update($aluno);

        return $aluno;
    }

    public function deleteService(int $idAluno): bool
    {
        $alunoExistente = $this->alunoDAO->findById($idAluno);

        if ($alunoExistente === null) {
            throw new ErrorResponse(
                404,
                'Aluno não encontrado',
                ['message' => "Não existe aluno com id {$idAluno}."]
            );
        }

        $cobrancasVinculadas = $this->cobrancaDAO->findByField(
            'Aluno_idAluno',
            $idAluno
        );

        if (count($cobrancasVinculadas) > 0) {
            throw new ErrorResponse(
                409,
                'Não foi possível excluir o aluno',
                [
                    'message' => 'Existem cobranças de mensalidade vinculadas a esse aluno. '
                        . 'Resolva esses vínculos antes de excluí-lo.'
                ]
            );
        }

        return $this->alunoDAO->delete($alunoExistente);
    }

    private function montarAluno(array $dadosAluno): Aluno
    {
        if (
            !isset($dadosAluno['nomeAluno'])
            || !is_string($dadosAluno['nomeAluno'])
        ) {
            throw new InvalidArgumentException(
                'O campo "nomeAluno" é obrigatório e deve ser um texto.'
            );
        }

        $dadosFuncionario = $dadosAluno['funcionario'] ?? null;

        if ($dadosFuncionario instanceof stdClass) {
            $dadosFuncionario = (array) $dadosFuncionario;
        }

        if (
            !is_array($dadosFuncionario)
            || !isset($dadosFuncionario['idFuncionario'])
            || !is_int($dadosFuncionario['idFuncionario'])
            || $dadosFuncionario['idFuncionario'] <= 0
        ) {
            throw new InvalidArgumentException(
                'Informe "funcionario" com um "idFuncionario" inteiro maior que zero.'
            );
        }

        $funcionario = $this->funcionarioDAO->findById(
            $dadosFuncionario['idFuncionario']
        );

        if ($funcionario === null) {
            throw new ErrorResponse(
                400,
                'Professor informado não existe',
                ['message' => 'Informe o ID de um funcionário já cadastrado.']
            );
        }

        $aluno = new Aluno();

        $aluno->setNomeAluno($dadosAluno['nomeAluno']);
        $aluno->setTelefone($dadosAluno['telefone'] ?? null);
        $aluno->setEmail($dadosAluno['email'] ?? null);
        $aluno->setInstrumento($dadosAluno['instrumento'] ?? null);
        $aluno->setFuncionario($funcionario);

        return $aluno;
    }

    private function verificarEmailDuplicado(
        ?string $email,
        ?int $idIgnorado = null
    ): void {
        if ($email === null) {
            return;
        }

        $alunosEncontrados = $this->alunoDAO->findByField('email', $email);

        foreach ($alunosEncontrados as $outroAluno) {
            if ($outroAluno->getIdAluno() !== $idIgnorado) {
                throw new ErrorResponse(
                    409,
                    'Aluno já cadastrado',
                    ['message' => 'Outro aluno já utiliza esse e-mail.']
                );
            }
        }
    }
}
