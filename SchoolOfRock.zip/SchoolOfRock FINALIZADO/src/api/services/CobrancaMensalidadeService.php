<?php

namespace Api\services;

use Api\Models\CobrancaMensalidade;
use Api\DAO\CobrancaMensalidadeDAO;
use Api\DAO\AlunoDAO;
use Api\DAO\PagamentoDAO;
use Api\Http\ErrorResponse;
use InvalidArgumentException;
use stdClass;

/**
 * Regras de negócio das cobranças de mensalidade.
 */
class CobrancaMensalidadeService
{
    private CobrancaMensalidadeDAO $cobrancaDAO;
    private AlunoDAO $alunoDAO;
    private PagamentoDAO $pagamentoDAO;

    public function __construct(
        CobrancaMensalidadeDAO $cobrancaDAO,
        AlunoDAO $alunoDAO,
        PagamentoDAO $pagamentoDAO
    ) {
        $this->cobrancaDAO = $cobrancaDAO;
        $this->alunoDAO = $alunoDAO;
        $this->pagamentoDAO = $pagamentoDAO;
    }

    public function createService(stdClass $objPHP): CobrancaMensalidade
    {
        if (
            !isset($objPHP->cobranca)
            || !($objPHP->cobranca instanceof stdClass)
        ) {
            throw new InvalidArgumentException(
                'O campo "cobranca" é obrigatório e deve ser um objeto.'
            );
        }

        $cobranca = $this->montarCobranca((array) $objPHP->cobranca);

        return $this->cobrancaDAO->create($cobranca);
    }

    public function countService(): int
    {
        return $this->cobrancaDAO->count();
    }

    public function findAllService(): array
    {
        return $this->cobrancaDAO->findAll();
    }

    public function findByIdService(int $idCobranca): ?CobrancaMensalidade
    {
        return $this->cobrancaDAO->findById($idCobranca);
    }

    public function updateService(int $idCobranca, array $requestBody): CobrancaMensalidade
    {
        $cobrancaExistente = $this->cobrancaDAO->findById($idCobranca);

        if ($cobrancaExistente === null) {
            throw new ErrorResponse(
                404,
                'Cobrança não encontrada',
                ['message' => "Não existe cobrança com id {$idCobranca}."]
            );
        }

        if (
            !isset($requestBody['cobranca'])
            || !is_array($requestBody['cobranca'])
        ) {
            throw new InvalidArgumentException(
                'O campo "cobranca" é obrigatório e deve conter os dados da cobrança.'
            );
        }

        $cobranca = $this->montarCobranca($requestBody['cobranca']);
        $cobranca->setIdCobranca($idCobranca);

        $this->cobrancaDAO->update($cobranca);

        return $cobranca;
    }

    public function deleteService(int $idCobranca): bool
    {
        $cobrancaExistente = $this->cobrancaDAO->findById($idCobranca);

        if ($cobrancaExistente === null) {
            throw new ErrorResponse(
                404,
                'Cobrança não encontrada',
                ['message' => "Não existe cobrança com id {$idCobranca}."]
            );
        }

        $pagamentosVinculados = $this->pagamentoDAO->findByField(
            'Cobranca_idCobranca',
            $idCobranca
        );

        if (count($pagamentosVinculados) > 0) {
            throw new ErrorResponse(
                409,
                'Não foi possível excluir a cobrança',
                [
                    'message' => 'Existem pagamentos vinculados a essa cobrança. '
                        . 'Resolva esses vínculos antes de excluí-la.'
                ]
            );
        }

        return $this->cobrancaDAO->delete($cobrancaExistente);
    }

    private function montarCobranca(array $dadosCobranca): CobrancaMensalidade
    {
        if (
            !isset($dadosCobranca['valor'])
            || (!is_int($dadosCobranca['valor']) && !is_float($dadosCobranca['valor']))
        ) {
            throw new InvalidArgumentException(
                'O campo "valor" é obrigatório e deve ser um número.'
            );
        }

        if (
            !isset($dadosCobranca['vencimento'])
            || !is_string($dadosCobranca['vencimento'])
        ) {
            throw new InvalidArgumentException(
                'O campo "vencimento" é obrigatório e deve ser um texto no formato AAAA-MM-DD.'
            );
        }

        $dadosAluno = $dadosCobranca['aluno'] ?? null;

        if ($dadosAluno instanceof stdClass) {
            $dadosAluno = (array) $dadosAluno;
        }

        if (
            !is_array($dadosAluno)
            || !isset($dadosAluno['idAluno'])
            || !is_int($dadosAluno['idAluno'])
            || $dadosAluno['idAluno'] <= 0
        ) {
            throw new InvalidArgumentException(
                'Informe "aluno" com um "idAluno" inteiro maior que zero.'
            );
        }

        $aluno = $this->alunoDAO->findById($dadosAluno['idAluno']);

        if ($aluno === null) {
            throw new ErrorResponse(
                400,
                'Aluno informado não existe',
                ['message' => 'Informe o ID de um aluno já cadastrado.']
            );
        }

        $cobranca = new CobrancaMensalidade();

        $cobranca->setValor((float) $dadosCobranca['valor']);
        $cobranca->setVencimento($dadosCobranca['vencimento']);
        $cobranca->setStatusCobranca($dadosCobranca['statusCobranca'] ?? 'pendente');
        $cobranca->setAluno($aluno);

        return $cobranca;
    }
}
