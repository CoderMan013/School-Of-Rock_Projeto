<?php

namespace Api\services;

use Api\Models\Pagamento;
use Api\DAO\PagamentoDAO;
use Api\DAO\CobrancaMensalidadeDAO;
use Api\Http\ErrorResponse;
use InvalidArgumentException;
use stdClass;

/**
 * Regras de negócio dos pagamentos.
 */
class PagamentoService
{
    private PagamentoDAO $pagamentoDAO;
    private CobrancaMensalidadeDAO $cobrancaDAO;

    public function __construct(
        PagamentoDAO $pagamentoDAO,
        CobrancaMensalidadeDAO $cobrancaDAO
    ) {
        $this->pagamentoDAO = $pagamentoDAO;
        $this->cobrancaDAO = $cobrancaDAO;
    }

    public function createService(stdClass $objPHP): Pagamento
    {
        if (
            !isset($objPHP->pagamento)
            || !($objPHP->pagamento instanceof stdClass)
        ) {
            throw new InvalidArgumentException(
                'O campo "pagamento" é obrigatório e deve ser um objeto.'
            );
        }

        $pagamento = $this->montarPagamento((array) $objPHP->pagamento);

        return $this->pagamentoDAO->create($pagamento);
    }

    public function countService(): int
    {
        return $this->pagamentoDAO->count();
    }

    public function findAllService(): array
    {
        return $this->pagamentoDAO->findAll();
    }

    public function findByIdService(int $idPagamento): ?Pagamento
    {
        return $this->pagamentoDAO->findById($idPagamento);
    }

    public function updateService(int $idPagamento, array $requestBody): Pagamento
    {
        $pagamentoExistente = $this->pagamentoDAO->findById($idPagamento);

        if ($pagamentoExistente === null) {
            throw new ErrorResponse(
                404,
                'Pagamento não encontrado',
                ['message' => "Não existe pagamento com id {$idPagamento}."]
            );
        }

        if (
            !isset($requestBody['pagamento'])
            || !is_array($requestBody['pagamento'])
        ) {
            throw new InvalidArgumentException(
                'O campo "pagamento" é obrigatório e deve conter os dados do pagamento.'
            );
        }

        $pagamento = $this->montarPagamento($requestBody['pagamento']);
        $pagamento->setIdPagamento($idPagamento);

        $this->pagamentoDAO->update($pagamento);

        return $pagamento;
    }

    public function deleteService(int $idPagamento): bool
    {
        $pagamentoExistente = $this->pagamentoDAO->findById($idPagamento);

        if ($pagamentoExistente === null) {
            throw new ErrorResponse(
                404,
                'Pagamento não encontrado',
                ['message' => "Não existe pagamento com id {$idPagamento}."]
            );
        }

        return $this->pagamentoDAO->delete($pagamentoExistente);
    }

    private function montarPagamento(array $dadosPagamento): Pagamento
    {
        $dadosCobranca = $dadosPagamento['cobranca'] ?? null;

        if ($dadosCobranca instanceof stdClass) {
            $dadosCobranca = (array) $dadosCobranca;
        }

        if (
            !is_array($dadosCobranca)
            || !isset($dadosCobranca['idCobranca'])
            || !is_int($dadosCobranca['idCobranca'])
            || $dadosCobranca['idCobranca'] <= 0
        ) {
            throw new InvalidArgumentException(
                'Informe "cobranca" com um "idCobranca" inteiro maior que zero.'
            );
        }

        $cobranca = $this->cobrancaDAO->findById($dadosCobranca['idCobranca']);

        if ($cobranca === null) {
            throw new ErrorResponse(
                400,
                'Cobrança informada não existe',
                ['message' => 'Informe o ID de uma cobrança já cadastrada.']
            );
        }

        $valorPago = $dadosPagamento['valorPago'] ?? null;

        if (
            $valorPago !== null
            && !is_int($valorPago)
            && !is_float($valorPago)
        ) {
            throw new InvalidArgumentException(
                'O campo "valorPago" deve ser um número.'
            );
        }

        $formaPagamento = $dadosPagamento['formaPagamento'] ?? null;

        if ($formaPagamento !== null && !is_string($formaPagamento)) {
            throw new InvalidArgumentException(
                'O campo "formaPagamento" deve ser um texto.'
            );
        }

        $dataPagamento = $dadosPagamento['dataPagamento'] ?? null;

        if ($dataPagamento !== null && !is_string($dataPagamento)) {
            throw new InvalidArgumentException(
                'O campo "dataPagamento" deve ser um texto no formato AAAA-MM-DD.'
            );
        }

        $pagamento = new Pagamento();

        $pagamento->setDataPagamento($dataPagamento);
        $pagamento->setValorPago($valorPago === null ? null : (float) $valorPago);
        $pagamento->setFormaPagamento($formaPagamento);
        $pagamento->setCobranca($cobranca);

        return $pagamento;
    }
}
