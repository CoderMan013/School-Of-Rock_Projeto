<?php

namespace Api\services;

use Api\Models\Funcionario;
use Api\DAO\FuncionarioDAO;
use Api\DAO\CargoDAO;
use Api\DAO\AlunoDAO;
use Api\Http\ErrorResponse;
use Api\Http\TokenJWT;
use InvalidArgumentException;
use stdClass;

/**
 * Regras de negócio dos funcionários, incluindo autenticação.
 */
class FuncionarioService
{
    private FuncionarioDAO $funcionarioDAO;
    private CargoDAO $cargoDAO;
    private AlunoDAO $alunoDAO;
    private TokenJWT $jwt;

    public function __construct(
        FuncionarioDAO $funcionarioDAO,
        CargoDAO $cargoDAO,
        AlunoDAO $alunoDAO,
        TokenJWT $jwt
    ) {
        $this->funcionarioDAO = $funcionarioDAO;
        $this->cargoDAO = $cargoDAO;
        $this->alunoDAO = $alunoDAO;
        $this->jwt = $jwt;
    }

    public function createService(stdClass $objPHP): Funcionario
    {
        if (
            !isset($objPHP->funcionario)
            || !($objPHP->funcionario instanceof stdClass)
        ) {
            throw new InvalidArgumentException(
                'O campo "funcionario" é obrigatório e deve ser um objeto.'
            );
        }

        $dados = (array) $objPHP->funcionario;

        if (
            !isset($dados['senha'])
            || !is_string($dados['senha'])
            || $dados['senha'] === ''
        ) {
            throw new InvalidArgumentException(
                'O campo "senha" é obrigatório ao cadastrar um funcionário.'
            );
        }

        $funcionario = $this->montarFuncionario($dados);
        $funcionario->setSenha($dados['senha']);

        $this->verificarEmailDuplicado($funcionario->getEmail());

        return $this->funcionarioDAO->create($funcionario);
    }

    public function countService(): int
    {
        return $this->funcionarioDAO->count();
    }

    public function findAllService(): array
    {
        return $this->funcionarioDAO->findAll();
    }

    public function findByIdService(int $idFuncionario): ?Funcionario
    {
        return $this->funcionarioDAO->findById($idFuncionario);
    }

    public function updateService(int $idFuncionario, array $requestBody): Funcionario
    {
        $funcionarioExistente = $this->funcionarioDAO->findById($idFuncionario);

        if ($funcionarioExistente === null) {
            throw new ErrorResponse(
                404,
                'Funcionário não encontrado',
                ['message' => "Não existe funcionário com id {$idFuncionario}."]
            );
        }

        if (
            !isset($requestBody['funcionario'])
            || !is_array($requestBody['funcionario'])
        ) {
            throw new InvalidArgumentException(
                'O campo "funcionario" é obrigatório e deve conter os dados do funcionário.'
            );
        }

        $dados = $requestBody['funcionario'];

        $funcionario = $this->montarFuncionario($dados);
        $funcionario->setIdFuncionario($idFuncionario);

        // A senha só é trocada quando enviada preenchida.
        if (isset($dados['senha']) && is_string($dados['senha']) && $dados['senha'] !== '') {
            $funcionario->setSenha($dados['senha']);
        } else {
            $funcionario->setSenhaHash($funcionarioExistente->getSenhaHash());
        }

        $this->verificarEmailDuplicado($funcionario->getEmail(), $idFuncionario);

        $this->funcionarioDAO->update($funcionario);

        return $funcionario;
    }

    public function deleteService(int $idFuncionario): bool
    {
        $funcionarioExistente = $this->funcionarioDAO->findById($idFuncionario);

        if ($funcionarioExistente === null) {
            throw new ErrorResponse(
                404,
                'Funcionário não encontrado',
                ['message' => "Não existe funcionário com id {$idFuncionario}."]
            );
        }

        $alunosVinculados = $this->alunoDAO->findByField(
            'Funcionario_idFuncionario',
            $idFuncionario
        );

        if (count($alunosVinculados) > 0) {
            throw new ErrorResponse(
                409,
                'Não foi possível excluir o funcionário',
                [
                    'message' => 'Existem alunos vinculados a esse funcionário como professor. '
                        . 'Resolva esses vínculos antes de excluí-lo.'
                ]
            );
        }

        return $this->funcionarioDAO->delete($funcionarioExistente);
    }

    /**
     * Realiza o login e gera o JWT.
     */
    public function loginService(array $dadosLogin): array
    {
        if (
            !isset($dadosLogin['email'])
            || !is_string($dadosLogin['email'])
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "email" é obrigatório e deve ser um texto.']
            );
        }

        $email = strtolower(trim($dadosLogin['email']));

        if (
            mb_strlen($email, 'UTF-8') > 64
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'Informe um e-mail válido com no máximo 64 caracteres.']
            );
        }

        if (
            !isset($dadosLogin['senha'])
            || !is_string($dadosLogin['senha'])
            || $dadosLogin['senha'] === ''
        ) {
            throw new ErrorResponse(
                400,
                'Erro na validação de dados',
                ['message' => 'O campo "senha" é obrigatório e deve ser um texto preenchido.']
            );
        }

        $senha = $dadosLogin['senha'];

        $funcionario = $this->funcionarioDAO->findByEmail($email);

        if ($funcionario === null || !$funcionario->verificarSenha($senha)) {
            throw new ErrorResponse(
                401,
                'E-mail ou senha inválidos',
                ['message' => 'Não foi possível autenticar o funcionário.']
            );
        }

        $cargo = $this->cargoDAO->findById(
            $funcionario->getCargo()->getIdCargo()
        );

        $funcionario->setCargo($cargo ?? $funcionario->getCargo());

        $claims = new stdClass();

        $claims->idFuncionario = $funcionario->getIdFuncionario();
        $claims->nomeFuncionario = $funcionario->getNomeFuncionario();
        $claims->email = $funcionario->getEmail();
        $claims->cargo = $cargo?->getNomeCargo();

        $token = $this->jwt->gerarToken($claims);

        return [
            'funcionario' => $funcionario->jsonSerialize(),
            'token' => $token
        ];
    }

    private function montarFuncionario(array $dadosFuncionario): Funcionario
    {
        if (
            !isset($dadosFuncionario['nomeFuncionario'])
            || !is_string($dadosFuncionario['nomeFuncionario'])
        ) {
            throw new InvalidArgumentException(
                'O campo "nomeFuncionario" é obrigatório e deve ser um texto.'
            );
        }

        if (
            !isset($dadosFuncionario['email'])
            || !is_string($dadosFuncionario['email'])
        ) {
            throw new InvalidArgumentException(
                'O campo "email" é obrigatório e deve ser um texto.'
            );
        }

        $dadosCargo = $dadosFuncionario['cargo'] ?? null;

        if ($dadosCargo instanceof stdClass) {
            $dadosCargo = (array) $dadosCargo;
        }

        if (
            !is_array($dadosCargo)
            || !isset($dadosCargo['idCargo'])
            || !is_int($dadosCargo['idCargo'])
            || $dadosCargo['idCargo'] <= 0
        ) {
            throw new InvalidArgumentException(
                'Informe "cargo" com um "idCargo" inteiro maior que zero.'
            );
        }

        $cargo = $this->cargoDAO->findById($dadosCargo['idCargo']);

        if ($cargo === null) {
            throw new ErrorResponse(
                400,
                'Cargo informado não existe',
                ['message' => 'Informe o ID de um cargo já cadastrado.']
            );
        }

        $funcionario = new Funcionario();

        $funcionario->setNomeFuncionario($dadosFuncionario['nomeFuncionario']);
        $funcionario->setEmail($dadosFuncionario['email']);
        $funcionario->setRecebeValeTransporte(
            (bool) ($dadosFuncionario['recebeValeTransporte'] ?? false)
        );
        $funcionario->setCargo($cargo);

        return $funcionario;
    }

    private function verificarEmailDuplicado(
        string $email,
        ?int $idIgnorado = null
    ): void {
        $funcionarioEncontrado = $this->funcionarioDAO->findByEmail($email);

        if (
            $funcionarioEncontrado !== null
            && $funcionarioEncontrado->getIdFuncionario() !== $idIgnorado
        ) {
            throw new ErrorResponse(
                409,
                'Funcionário já cadastrado',
                ['message' => 'Outro funcionário já utiliza esse e-mail.']
            );
        }
    }
}
